/*
GENERATED FILE, built by esbuild from src/. Edit the TypeScript sources, not this file.
*/

"use strict";
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

// src/main.ts
var main_exports = {};
__export(main_exports, {
  default: () => EditorDefaultsPlugin
});
module.exports = __toCommonJS(main_exports);
var import_obsidian5 = require("obsidian");

// node_modules/monkey-around/dist/index.mjs
function around(obj, factories) {
  const removers = Object.keys(factories).map((key) => around1(obj, key, factories[key]));
  return removers.length === 1 ? removers[0] : function() {
    removers.forEach((r) => r());
  };
}
function around1(obj, method, createWrapper) {
  const inherited = obj[method], hadOwn = obj.hasOwnProperty(method), original = hadOwn ? inherited : function() {
    return Object.getPrototypeOf(obj)[method].apply(this, arguments);
  };
  let current = createWrapper(original);
  if (inherited)
    Object.setPrototypeOf(current, inherited);
  Object.setPrototypeOf(wrapper, current);
  obj[method] = wrapper;
  return remove;
  function wrapper(...args) {
    if (current === original && obj[method] === wrapper)
      remove();
    return current.apply(this, args);
  }
  function remove() {
    if (obj[method] === wrapper) {
      if (hadOwn)
        obj[method] = original;
      else
        delete obj[method];
    }
    if (current === original)
      return;
    current = original;
    Object.setPrototypeOf(wrapper, inherited || Function);
  }
}

// src/defaults.ts
var ARROWS = { arrowleft: "\u2190", arrowright: "\u2192", arrowup: "\u2191", arrowdown: "\u2193" };
function comboKey(k, isMac) {
  const mods = new Set(k.modifiers.map((m) => m === "Mod" ? isMac ? "Meta" : "Ctrl" : m));
  return [...["Ctrl", "Meta", "Alt", "Shift"].filter((m) => mods.has(m)), k.key.toLowerCase()].join("+");
}
function hotkeyLabel(k, isMac) {
  return comboKey(k, isMac).split("+").map((p, i, all) => {
    if (i < all.length - 1) return p === "Meta" ? isMac ? "Cmd" : "Win" : isMac && p === "Alt" ? "Option" : p;
    return ARROWS[p] ?? (p.length === 1 ? p.toUpperCase() : p);
  }).join("+");
}
function hotkeyClashes(wanted, effective, isMac) {
  const out = [];
  for (const [command, keys] of Object.entries(wanted)) {
    if (!(command in effective)) continue;
    for (const k of keys) {
      const want = comboKey(k, isMac);
      for (const [other, theirs] of Object.entries(effective)) {
        if (other in wanted) continue;
        if (theirs.some((t) => comboKey(t, isMac) === want)) out.push({ command, other, label: hotkeyLabel(k, isMac) });
      }
    }
  }
  return out;
}
function list(items) {
  return items.length < 2 ? items[0] ?? "" : `${items.slice(0, -1).join(", ")} and ${items[items.length - 1]}`;
}

// src/setup/hotkeys.ts
var ORDER = ["Mod", "Ctrl", "Meta", "Alt", "Shift"];
var isModifier = (m) => ORDER.includes(m);
function parseHotkey(text) {
  const s = text.trim();
  if (!s) return null;
  const parts = s.endsWith("++") ? [...s.slice(0, -2).split("+"), "+"] : s.split("+");
  const key = parts.pop() ?? "";
  if (!key) return null;
  const modifiers = [];
  for (const p of parts) {
    if (!isModifier(p) || modifiers.includes(p)) return null;
    modifiers.push(p);
  }
  return { modifiers: ORDER.filter((m) => modifiers.includes(m)), key };
}
function formatHotkey(h) {
  const key = h.key.length === 1 ? h.key.toUpperCase() : h.key;
  return [...ORDER.filter((m) => h.modifiers.includes(m)), key].join("+");
}
function normalHotkeys(list2) {
  const out = [];
  for (const t of list2) {
    const h = parseHotkey(t);
    if (!h) return null;
    out.push(formatHotkey(h));
  }
  return out;
}

// src/setup/setup.ts
var import_obsidian2 = require("obsidian");

// src/drift.ts
var DriftGuard = class {
  constructor(max = 5, windowMs = 1e4, longMax = 10, longWindowMs = 6e5) {
    this.max = max;
    this.windowMs = windowMs;
    this.longMax = longMax;
    this.longWindowMs = longWindowMs;
    this.times = /* @__PURE__ */ new Map();
    this.warned = /* @__PURE__ */ new Set();
    this.stopped = /* @__PURE__ */ new Set();
    this.newlyStopped = [];
  }
  /** Whether item `id` may be put back again at `now`. */
  allow(id, now) {
    if (this.stopped.has(id)) return false;
    const times = (this.times.get(id) ?? []).filter((t) => now - t < this.longWindowMs);
    this.times.set(id, times);
    if (times.length >= this.longMax) {
      this.stopped.add(id);
      this.newlyStopped.push(id);
      console.warn(`[editor-defaults] ${id} keeps being changed back; not enforcing it again this session`);
      return false;
    }
    if (times.filter((t) => now - t < this.windowMs).length < this.max) return true;
    if (!this.warned.has(id)) {
      this.warned.add(id);
      console.warn(`[editor-defaults] ${id} keeps changing back; not enforcing it again for now`);
    }
    return false;
  }
  /** When item `id`, refused at `now`, may be put back again; null when it isn't waiting (or is stopped). */
  retryAt(id, now) {
    if (this.stopped.has(id)) return null;
    const recent = (this.times.get(id) ?? []).filter((t) => now - t < this.windowMs);
    return recent.length < this.max ? null : recent[recent.length - this.max] + this.windowMs;
  }
  record(id, now) {
    this.times.set(id, [...this.times.get(id) ?? [], now]);
  }
  /** The items stopped for the session since the last call. */
  takeStopped() {
    const out = this.newlyStopped;
    this.newlyStopped = [];
    return out;
  }
};

// src/setup/json.ts
function isObject(v) {
  return typeof v === "object" && v !== null && !Array.isArray(v);
}
function toJson(v, seen = /* @__PURE__ */ new WeakSet()) {
  if (v === null || typeof v === "boolean" || typeof v === "string") return v;
  if (typeof v === "number") return Number.isFinite(v) ? v : void 0;
  if (typeof v !== "object") return void 0;
  if (seen.has(v)) return void 0;
  seen.add(v);
  try {
    if (Array.isArray(v)) {
      const out2 = [];
      for (const x of v) {
        const j = toJson(x, seen);
        if (j === void 0) return void 0;
        out2.push(j);
      }
      return out2;
    }
    const proto = Object.getPrototypeOf(v);
    if (proto !== Object.prototype && proto !== null) return void 0;
    const out = {};
    for (const [k, x] of Object.entries(v)) {
      const j = toJson(x, seen);
      if (j !== void 0) out[k] = j;
    }
    return out;
  } finally {
    seen.delete(v);
  }
}
function equal(a, b) {
  if (a === b) return true;
  if (Array.isArray(a) || Array.isArray(b)) {
    if (!Array.isArray(a) || !Array.isArray(b) || a.length !== b.length) return false;
    return a.every((x, i) => equal(x, b[i]));
  }
  if (isObject(a) && isObject(b)) {
    const ka = Object.keys(a);
    if (ka.length !== Object.keys(b).length) return false;
    return ka.every((k) => Object.hasOwn(b, k) && equal(a[k], b[k]));
  }
  return false;
}
function merged(base, values) {
  const out = isObject(base) ? { ...base } : {};
  for (const [k, v] of Object.entries(values)) {
    const now = out[k];
    out[k] = isObject(v) && isObject(now) ? merged(now, v) : clone(v);
  }
  return out;
}
function clone(v) {
  return structuredClone(v);
}
function differences(values, actual, prefix = "") {
  const out = [];
  const have = isObject(actual) ? actual : {};
  for (const [k, v] of Object.entries(values)) {
    const path = prefix ? `${prefix}.${k}` : k;
    const now = have[k];
    if (isObject(v) && isObject(now)) out.push(...differences(v, now, path));
    else if (!equal(v, now)) out.push(path);
  }
  return out;
}
function defaultAt(defaults, path) {
  if (!defaults) return void 0;
  if (typeof defaults === "function") return defaults(path);
  let v = defaults;
  for (const k of path.split(".")) v = isObject(v) ? v[k] : void 0;
  return v;
}
function capture(values, before, after, { ignore = [], defaults } = {}, prefix = "") {
  const out = { ...values };
  const result = { values: out, added: [], changed: [], removed: [] };
  const was = isObject(before) ? before : {};
  const now = isObject(after) ? after : {};
  for (const [k, v] of Object.entries(now)) {
    if (!prefix && ignore.includes(k)) continue;
    if (Object.hasOwn(was, k) && equal(was[k], v)) continue;
    const path = prefix ? `${prefix}.${k}` : k;
    const mine = values[k];
    const dflt = defaultAt(defaults, path);
    if (isObject(mine) && isObject(v)) {
      const inner = capture(mine, was[k], v, { defaults }, path);
      if (Object.keys(inner.values).length) out[k] = inner.values;
      else delete out[k];
      result.added.push(...inner.added);
      result.changed.push(...inner.changed);
      result.removed.push(...inner.removed);
    } else if (dflt !== void 0 && equal(dflt, v)) {
      if (mine !== void 0) {
        delete out[k];
        result.removed.push(path);
      }
    } else if (mine === void 0) {
      out[k] = clone(v);
      result.added.push(path);
    } else if (!equal(mine, v)) {
      out[k] = clone(v);
      result.changed.push(path);
    }
  }
  for (const k of Object.keys(was)) {
    if (Object.hasOwn(now, k) || !prefix && ignore.includes(k) || values[k] === void 0) continue;
    delete out[k];
    result.removed.push(prefix ? `${prefix}.${k}` : k);
  }
  return result;
}
function withoutDefaults(values, defaults, prefix = "") {
  const out = {};
  for (const [k, v] of Object.entries(values)) {
    const path = prefix ? `${prefix}.${k}` : k;
    const d = defaultAt(defaults, path);
    if (d !== void 0 && equal(d, v)) continue;
    if (isObject(v) && isObject(d)) {
      const inner = withoutDefaults(v, defaults, path);
      if (Object.keys(inner).length) out[k] = inner;
    } else out[k] = clone(v);
  }
  return out;
}

// src/setup/note.ts
var FENCE_LANG = "vault-settings";
var OPEN = /^(`{3,}|~{3,})[ \t]*vault-settings[ \t]*$/;
var HEADING = /^#{1,6}[ \t]+(.+?)[ \t#]*$/;
function findBlocks(text) {
  const out = [];
  const lines = text.split("\n");
  let offset = 0;
  let heading = "";
  let open = null;
  let otherFence = null;
  for (let i = 0; i < lines.length; i++) {
    const line = lines[i].replace(/\r$/, "");
    const next = offset + lines[i].length + (i < lines.length - 1 ? 1 : 0);
    if (open) {
      if (line.trim().startsWith(open.fence) && line.trim() === open.fence[0].repeat(line.trim().length)) {
        out.push({
          from: open.from,
          to: offset,
          end: next,
          yaml: text.slice(open.from, offset),
          heading: open.heading,
          line: open.line
        });
        open = null;
      }
    } else if (otherFence) {
      if (line.trim().startsWith(otherFence) && /^(`+|~+)$/.test(line.trim())) otherFence = null;
    } else {
      const m = OPEN.exec(line);
      if (m) open = { fence: m[1], from: next, line: i + 1, heading };
      else if (/^(`{3,}|~{3,})/.test(line.trim())) otherFence = /^(`{3,}|~{3,})/.exec(line.trim())?.[1] ?? null;
      else {
        const h = HEADING.exec(line);
        if (h) heading = h[1];
      }
    }
    offset = next;
  }
  if (open)
    out.push({
      from: open.from,
      to: text.length,
      end: text.length,
      yaml: text.slice(open.from),
      heading: open.heading,
      line: open.line
    });
  return out;
}
function replaceBlockYaml(text, block, yaml) {
  const body = yaml.endsWith("\n") ? yaml : `${yaml}
`;
  return text.slice(0, block.from) + body + text.slice(block.to);
}
function addLinesAfter(text, block, lines) {
  if (!lines.length) return text;
  let head = text.slice(0, block.end);
  if (!head.endsWith("\n")) head += "\n";
  const rest = text.slice(block.end);
  const add = `${lines.map((l) => `- ${l}`).join("\n")}
`;
  const log = /^\n((?:- [^\n]*(?:\n|$))+)/.exec(rest);
  if (log) {
    const before = log[1].endsWith("\n") ? log[1] : `${log[1]}
`;
    return `${head}
${before}${add}${rest.slice(log[0].length)}`;
  }
  return `${head}
${add}${rest === "" || rest.startsWith("\n") ? "" : "\n"}${rest}`;
}
function appendSection(text, heading, intro, yaml) {
  const body = yaml.endsWith("\n") ? yaml : `${yaml}
`;
  const sep = text.length === 0 ? "" : text.endsWith("\n\n") ? "" : text.endsWith("\n") ? "\n" : "\n\n";
  return `${text}${sep}## ${heading}

${intro}

\`\`\`${FENCE_LANG}
${body}\`\`\`
`;
}

// src/setup/model.ts
var OBSIDIAN_TARGETS = ["app", "core-plugins", "hotkeys", "property-types"];
var RESERVED = /* @__PURE__ */ new Set([
  "app",
  "appearance",
  "community-plugins",
  "core-plugins",
  "core-plugins-migration",
  "hotkeys",
  "types",
  "workspace",
  "workspace-mobile",
  "workspaces",
  "graph"
]);
function isReservedConfig(name) {
  return RESERVED.has(name) || name.startsWith("workspace");
}
var ID = /^[a-z0-9][a-z0-9._-]*$/i;
var REPO = /^[\w.-]+\/[\w.-]+$/;
function blockKey(b) {
  return b.kind === "plugin" ? `plugin:${b.id}` : b.target;
}
function checkCorePlugins(settings) {
  for (const [id, v] of Object.entries(settings)) {
    if (typeof v === "boolean") continue;
    if (isObject(v) && typeof v.enabled === "boolean" && (v.onlyWith === void 0 || typeof v.onlyWith === "string"))
      continue;
    return `core plugin "${id}": true, false, or { enabled: true/false, onlyWith: <plugin id> }`;
  }
  return null;
}
function checkHotkeys(settings) {
  for (const [id, v] of Object.entries(settings)) {
    if (!Array.isArray(v) || !v.every((k) => typeof k === "string") || !normalHotkeys(v))
      return `hotkeys of "${id}": a list like [Mod+Alt+ArrowLeft, "Mod+["] ([] for none)`;
  }
  return null;
}
function checkTypes(settings) {
  for (const [name, v] of Object.entries(settings))
    if (typeof v !== "string" || !v) return `property "${name}": a type such as text, date, datetime, multitext`;
  return null;
}
function parseBlock(value, at) {
  const fail = (message) => ({ at, message });
  if (!isObject(toJson(value))) return fail("the block must be a YAML mapping (key: value lines)");
  const v = toJson(value);
  if (!isObject(v)) return fail("the block must be a YAML mapping");
  const settings = v.settings ?? {};
  if (!isObject(settings)) return fail("settings: must be a mapping (key: value lines)");
  let only;
  if (v.only !== void 0) {
    if (v.only !== "desktop" && v.only !== "mobile") return fail("only: desktop or mobile");
    only = v.only;
  }
  if (typeof v.plugin === "string") {
    if (!ID.test(v.plugin)) return fail(`plugin: "${v.plugin}" isn't a plugin id`);
    let source = { type: "community" };
    if (v.source !== void 0 && v.source !== "community") {
      const m = typeof v.source === "string" ? /^github:(.+)$/.exec(v.source) : null;
      if (!m || !REPO.test(m[1])) return fail("source: community, or github:<owner>/<repo>");
      source = { type: "github", repo: m[1] };
    }
    const state = v.state ?? "enabled";
    if (state !== "enabled" && state !== "disabled" && state !== "uninstalled")
      return fail("state: enabled, disabled or uninstalled");
    if (v.version !== void 0 && typeof v.version !== "string")
      return fail('version: a release, in quotes ("1.2.3")');
    const ignore = v.ignore ?? [];
    if (!Array.isArray(ignore) || !ignore.every((k) => typeof k === "string"))
      return fail("ignore: a list of settings keys");
    return {
      kind: "plugin",
      id: v.plugin,
      source,
      state,
      ...typeof v.version === "string" ? { version: v.version } : {},
      ignore,
      at,
      ...only ? { only } : {},
      settings
    };
  }
  if (typeof v.obsidian === "string") {
    const name = v.obsidian;
    let target;
    if (OBSIDIAN_TARGETS.includes(name)) {
      target = name;
      const err = target === "core-plugins" ? checkCorePlugins(settings) : target === "hotkeys" ? checkHotkeys(settings) : target === "property-types" ? checkTypes(settings) : null;
      if (err) return fail(err);
    } else if (ID.test(name) && !isReservedConfig(name)) target = `config:${name}`;
    else return fail(`obsidian: ${OBSIDIAN_TARGETS.join(", ")}, or the name of a config file (canvas\u2026)`);
    return { kind: "obsidian", target, at, ...only ? { only } : {}, settings };
  }
  return fail("a block starts with plugin: <id> or obsidian: <what>");
}
function readNote(text, parseYaml2) {
  const blocks = [];
  const errors = [];
  const seen = /* @__PURE__ */ new Set();
  for (const at of findBlocks(text)) {
    let value;
    try {
      value = parseYaml2(at.yaml);
    } catch (e) {
      errors.push({ at, message: `YAML: ${e instanceof Error ? e.message.split("\n")[0] : String(e)}` });
      continue;
    }
    const b = parseBlock(value, at);
    if (!("kind" in b)) {
      errors.push(b);
      continue;
    }
    const key = blockKey(b);
    if (seen.has(key)) {
      errors.push({ at, message: `${key.replace(/^config:/, "")} is set by an earlier block already` });
      continue;
    }
    seen.add(key);
    blocks.push(b);
  }
  return { blocks, errors };
}
function appliesHere(b, isMobile) {
  return !b.only || b.only === "mobile" === isMobile;
}
function wantedCorePlugins(settings, isLoaded) {
  const out = {};
  for (const [id, v] of Object.entries(settings)) {
    if (typeof v === "boolean") out[id] = v;
    else if (isObject(v) && typeof v.enabled === "boolean") {
      if (typeof v.onlyWith === "string" && !isLoaded(v.onlyWith)) continue;
      out[id] = v.enabled;
    }
  }
  return out;
}
function blockValue(b, settings) {
  const out = {};
  if (b.kind === "plugin") {
    out.plugin = b.id;
    out.source = b.source.type === "github" ? `github:${b.source.repo}` : "community";
    if (b.state !== "enabled") out.state = b.state;
    if (b.version) out.version = b.version;
    if (b.ignore.length) out.ignore = b.ignore;
  } else out.obsidian = b.target.replace(/^config:/, "");
  if (b.only) out.only = b.only;
  out.settings = settings;
  return out;
}

// src/setup/targets.ts
var top = (paths) => [...new Set(paths.map((p) => p.split(".")[0]))];
async function readJsonFile(app, path) {
  try {
    if (!await app.vault.adapter.exists(path)) return {};
    const v = toJson(JSON.parse(await app.vault.adapter.read(path)));
    return isObject(v) ? v : {};
  } catch {
    return {};
  }
}
async function writeJsonFile(app, path, value) {
  const dir = path.slice(0, path.lastIndexOf("/"));
  if (dir && !await app.vault.adapter.exists(dir)) await app.vault.adapter.mkdir(dir);
  await app.vault.adapter.write(path, JSON.stringify(value, null, 2));
}
var APP_NAMES = {
  newLinkFormat: "New link format",
  attachmentFolderPath: "Default location for new attachments",
  trashOption: "Deleted files",
  alwaysUpdateLinks: "Automatically update internal links",
  showUnsupportedFiles: "Detect all file extensions",
  newFileLocation: "Default location for new notes",
  newFileFolderPath: "Folder to create new notes in"
};
function appTarget(app) {
  const vault = app.vault;
  const defaultOf = (key) => {
    const cfg = vault.config;
    if (!cfg || typeof vault.getConfig !== "function") return void 0;
    const had = Object.hasOwn(cfg, key);
    const value = cfg[key];
    delete cfg[key];
    try {
      return toJson(vault.getConfig(key));
    } finally {
      if (had) cfg[key] = value;
    }
  };
  return {
    key: "app",
    name: (p) => `"${APP_NAMES[p] ?? p}"`,
    read: () => {
      const v = toJson(vault.config ?? {});
      return Promise.resolve(isObject(v) ? v : {});
    },
    wanted: (s) => s,
    defaults: (path) => {
      const [k, ...rest] = path.split(".");
      let v = defaultOf(k);
      for (const r of rest) v = isObject(v) ? v[r] : void 0;
      return v;
    },
    write: (values, paths) => {
      for (const k of top(paths)) {
        const v = values[k];
        const now = toJson(vault.getConfig?.(k));
        vault.setConfig?.(k, isObject(v) && isObject(now) ? merged(now, v) : v);
      }
      return Promise.resolve();
    }
  };
}
function corePluginsTarget(app, isLoaded) {
  const plugins = () => app.internalPlugins?.plugins ?? {};
  return {
    key: "core-plugins",
    name: (id) => `core plugin ${plugins()[id]?.instance?.name ?? id}`,
    read: () => Promise.resolve(Object.fromEntries(Object.entries(plugins()).map(([id, p]) => [id, p.enabled]))),
    wanted: (s) => wantedCorePlugins(s, isLoaded),
    // a core plugin that doesn't say is off in a new vault
    defaults: (id) => plugins()[id] ? plugins()[id]?.instance?.defaultOn ?? false : void 0,
    write: async (values, paths) => {
      for (const id of top(paths)) {
        const p = plugins()[id];
        const on = values[id] === true;
        const turn = on ? p?.enable : p?.disable;
        if (!p || p.enabled === on || typeof turn !== "function") continue;
        try {
          await turn.call(p, true);
        } catch (e) {
          console.error(`[editor-defaults] could not turn core plugin ${id} ${on ? "on" : "off"}`, e);
        }
      }
    }
  };
}
function hotkeysTarget(app, commandName) {
  const hm = () => app.hotkeyManager;
  const strings = (keys) => keys.map(formatHotkey);
  return {
    key: "hotkeys",
    name: (id) => `the hotkeys of "${commandName(id)}"`,
    read: () => {
      const custom = hm()?.customKeys ?? {};
      return Promise.resolve(Object.fromEntries(Object.entries(custom).map(([id, keys]) => [id, strings(keys)])));
    },
    wanted: (s) => Object.fromEntries(
      Object.entries(s).flatMap(([id, v]) => {
        const n = Array.isArray(v) && v.every((k) => typeof k === "string") ? normalHotkeys(v) : null;
        return n ? [[id, n]] : [];
      })
    ),
    defaults: (id) => strings(hm()?.getDefaultHotkeys?.(id) ?? []),
    write: async (values, paths) => {
      const m = hm();
      if (typeof m?.setHotkeys !== "function") return;
      for (const id of top(paths)) {
        const v = values[id];
        if (!Array.isArray(v)) continue;
        m.setHotkeys(
          id,
          v.flatMap((k) => {
            const h = typeof k === "string" ? parseHotkey(k) : null;
            return h ? [h] : [];
          })
        );
      }
      try {
        await m.save?.();
      } catch (e) {
        console.error("[editor-defaults] could not save hotkeys", e);
      }
    }
  };
}
function propertyTypesTarget(app) {
  const file = () => `${app.vault.configDir}/types.json`;
  return {
    key: "property-types",
    name: (p) => `the type of property ${p}`,
    read: async () => {
      const t = (await readJsonFile(app, file())).types;
      return isObject(t) ? t : {};
    },
    wanted: (s) => s,
    write: async (values, paths) => {
      const mtm = app.metadataTypeManager;
      for (const name of top(paths)) {
        const w = values[name];
        if (typeof w === "string") await mtm?.setType?.(name, w);
      }
    }
  };
}
function configFileTarget(app, name) {
  const file = () => `${app.vault.configDir}/${name}.json`;
  return {
    key: `config:${name}`,
    name: (p) => `${p} in ${name}.json`,
    read: () => readJsonFile(app, file()),
    wanted: (s) => s,
    write: async (values) => {
      const all = merged(await readJsonFile(app, file()), values);
      await writeJsonFile(app, file(), all);
      const core = app.internalPlugins?.plugins?.[name]?.instance;
      if (typeof core?.onExternalSettingsChange === "function") await core.onExternalSettingsChange();
      else if (isObject(core?.options)) Object.assign(core.options, all);
    }
  };
}
var asLoaded = (p) => typeof p === "object" && p !== null ? p : null;
function pluginTarget(app, id, opts) {
  const plugins = () => app.plugins;
  const dir = () => plugins()?.manifests?.[id]?.dir ?? `${app.vault.configDir}/plugins/${id}`;
  const file = () => `${dir()}/data.json`;
  const pluginName = () => plugins()?.manifests?.[id]?.name ?? id;
  return {
    key: `plugin:${id}`,
    name: (p) => `${pluginName()} setting ${p}`,
    read: () => readJsonFile(app, file()),
    wanted: (s) => s,
    ...opts.defaults ? { defaults: opts.defaults } : {},
    write: async (values) => {
      const all = merged(await readJsonFile(app, file()), values);
      if (id === opts.selfId) return opts.writeSelf(all);
      const pm = plugins();
      if (!pm?.manifests?.[id]) return;
      const loaded = asLoaded(pm.plugins?.[id]);
      if (loaded && typeof loaded.onExternalSettingsChange === "function") {
        await writeJsonFile(app, file(), all);
        await loaded.onExternalSettingsChange();
      } else if (loaded) {
        await pm.disablePlugin?.(id);
        await writeJsonFile(app, file(), all);
        await pm.enablePlugin?.(id);
      } else await writeJsonFile(app, file(), all);
    }
  };
}

// src/setup/modal.ts
var import_obsidian = require("obsidian");
var MAX_LISTED = 12;
var SetupModal = class extends import_obsidian.Modal {
  constructor(app, ask) {
    super(app);
    this.ask = ask;
    this.choice = "later";
    this.done = null;
  }
  /** Opens the dialog; resolves with the choice ("later" when it's closed some other way). */
  choose() {
    return new Promise((resolve) => {
      this.done = resolve;
      this.open();
    });
  }
  onOpen() {
    const { contentEl, ask } = this;
    this.setTitle("Set up this vault from its settings note");
    contentEl.createEl("p", { text: `Editor Defaults (Archit) read ${ask.notePath}.` });
    const section = (title, items) => {
      if (!items.length) return;
      contentEl.createEl("p", { text: title });
      const ul = contentEl.createEl("ul");
      for (const i of items.slice(0, MAX_LISTED)) ul.createEl("li", { text: i });
      if (items.length > MAX_LISTED) ul.createEl("li", { text: `and ${items.length - MAX_LISTED} more` });
    };
    section("Plugins to install (from their GitHub releases):", ask.install);
    section("Plugins to remove:", ask.uninstall);
    section("Settings this vault holds differently from the note:", ask.differences);
    const buttons = new import_obsidian.Setting(contentEl);
    buttons.addButton(
      (b) => b.setButtonText(ask.install.length || ask.uninstall.length ? "Apply and install" : "Apply the note").setCta().onClick(() => this.pick("apply"))
    );
    if (ask.canAdopt)
      buttons.addButton((b) => b.setButtonText("Update the note from this vault").onClick(() => this.pick("adopt")));
    buttons.addButton((b) => b.setButtonText("Not now").onClick(() => this.pick("later")));
  }
  pick(c) {
    this.choice = c;
    this.close();
  }
  onClose() {
    this.contentEl.empty();
    this.done?.(this.choice);
    this.done = null;
  }
};

// src/vault-settings.md
var vault_settings_default = "---\ntype: system\ncreated: 2026-11-09T12:00:00\n---\n\n# Vault settings\n\nThis vault's plugins and the settings that differ from their defaults, with the reason for each. Editor Defaults\n(Archit) reads the `vault-settings` blocks:\n\n- **At start, and whenever this note changes,** it applies them. A missing plugin is installed after one click.\n- **A change you make in Settings** is written back into the blocks, with a dated line.\n- **Any other change** (a synced file, another plugin) is put back.\n\nOnly the blocks are rewritten; the text around them is never touched. A setting back at its default is taken out\nof its block, so each block lists only real choices.\n\n## Obsidian\n\n- **Links are written as the full path from the vault root.** Every link reads the same wherever it is, and it\n  survives notes being moved around.\n- **Links update when a note moves.**\n- **Attachments go to `u/`.**\n- **Deleted files go to `.trash/` in the vault.** You can get them back on every device, and vault-sync carries\n  them.\n- **Other files are shown in the file explorer** (PDFs, canvases, drawings).\n\n```vault-settings\nobsidian: app\nsettings:\n  newLinkFormat: absolute\n  alwaysUpdateLinks: true\n  attachmentFolderPath: u\n  trashOption: local\n  showUnsupportedFiles: true\n```\n\n## Core plugins\n\nSome core plugins are replaced by community plugins:\n\n- **Backlinks** by Backlinks Full View's panes, so it's off, but only while Backlinks Full View is enabled.\n- **Templates** by Templater, so it's off only while Templater is enabled.\n\nDaily notes are off because logs come from Templater's folder templates. Sync is off because the vault is synced\nwith git (vault-sync).\n\n```vault-settings\nobsidian: core-plugins\nsettings:\n  backlink:\n    enabled: false\n    onlyWith: backlinks-full-view\n  templates:\n    enabled: false\n    onlyWith: templater-obsidian\n  daily-notes: false\n  sync: false\n```\n\n## Hotkeys\n\n- **Navigate back and forward** also get Mod+[ and Mod+]: one hand, the same keys as in a browser.\n- **Templater's \"Create new note from template\"** is Alt+N.\n\nA hotkey for a plugin that isn't installed is kept, and works once the plugin is.\n\n```vault-settings\nobsidian: hotkeys\nsettings:\n  app:go-back: [Mod+Alt+ArrowLeft, \"Mod+[\"]\n  app:go-forward: [Mod+Alt+ArrowRight, \"Mod+]\"]\n  templater-obsidian:create-new-note-from-template: [Alt+N]\n```\n\n## Property types\n\nThese are the note system's properties (`system.md`): they're dates, lists or checkboxes, so Dataview, Bases and\nthe weekly review read them the same everywhere.\n\n```vault-settings\nobsidian: property-types\nsettings:\n  type: text\n  created: datetime\n  status: text\n  distill: checkbox\n  topics: multitext\n  parents: multitext\n  parent: text\n  sources: multitext\n  kind: text\n  author: multitext\n  year: number\n  url: text\n  org: multitext\n  cadence: text\n  area: multitext\n  due: date\n  private: checkbox\n```\n\n## Canvas\n\nNew canvases go to `c/`.\n\n```vault-settings\nobsidian: canvas\nsettings:\n  newFileLocation: folder\n  newFileFolderPath: c\n```\n\n## Templater\n\nTemplater replaces core Templates:\n\n- **Templates** are in `_t/`.\n- **Folder templates** give each folder its note type when a note is created there.\n- **The cursor** jumps to the template's `tp.file.cursor()`.\n- **The log template** has its own hotkey command.\n\n```vault-settings\nplugin: templater-obsidian\nsource: community\nsettings:\n  templates_folder: _t\n  trigger_on_file_creation_mode: folder\n  auto_jump_to_cursor: true\n  folder_templates:\n    - folder: \"0\"\n      template: _t/log.md\n    - folder: z\n      template: _t/zettel.md\n    - folder: n\n      template: _t/entity.md\n    - folder: p\n      template: _t/project.md\n    - folder: x\n      template: _t/moc.md\n    - folder: _s\n      template: _t/system.md\n  enabled_templates_hotkeys: [_t/log.md]\n```\n\n## Dataview\n\nDataview runs the dashboards' queries in `x/`. Its defaults are fine.\n\n```vault-settings\nplugin: dataview\nsource: community\n```\n\n## Tasks\n\nTodos use Dataview's format (`[due:: \u2026]`), so Dataview queries read them too. Tasks keeps its defaults out of reach,\nso a setting changed back to its default stays listed here.\n\n```vault-settings\nplugin: obsidian-tasks-plugin\nsource: community\nsettings:\n  taskFormat: dataview\n```\n\n## Advanced Tables\n\n```vault-settings\nplugin: table-editor-obsidian\nsource: community\n```\n\n## Calendar\n\n```vault-settings\nplugin: calendar\nsource: community\n```\n\n## Style Settings\n\n```vault-settings\nplugin: obsidian-style-settings\nsource: community\n```\n\n## Advanced Canvas\n\n```vault-settings\nplugin: advanced-canvas\nsource: community\n```\n\n## Enhanced Canvas\n\n```vault-settings\nplugin: enhanced-canvas\nsource: community\n```\n\n## PDF++\n\n```vault-settings\nplugin: pdf-plus\nsource: community\n```\n\n## Omnisearch\n\n```vault-settings\nplugin: omnisearch\nsource: community\n```\n\n## Excalidraw\n\nEvery drawing lives in `d/`: the drawings themselves, also those created from a note, the template, the scripts,\nthe libraries and the CJK fonts. The library itself (`library2`) is your drawings' data, not a setting.\n\n```vault-settings\nplugin: obsidian-excalidraw-plugin\nsource: community\nignore: [library2]\nsettings:\n  folder: d\n  embedUseExcalidrawFolder: true\n  templateFilePath: d/Template.excalidraw\n  scriptFolderPath: d/Scripts\n  libraryFolderPath: d/Libraries\n  fontAssetsPath: d/CJK Fonts\n```\n\n## BRAT\n\nBRAT updates the GitHub plugins below from their releases. Editor Defaults (Archit) adds every block with a\n`github:` source to its list.\n\n```vault-settings\nplugin: obsidian42-brat\nsource: community\n```\n\n## Backlinks Full View\n\n```vault-settings\nplugin: backlinks-full-view\nsource: github:archit90/obsidian-backlinks-full-view\n```\n\n## Editor Multiple Lanes\n\n```vault-settings\nplugin: editor-multiple-lanes\nsource: github:archit90/obsidian-editor-multiple-lanes\n```\n\n## Editor Outliner\n\n```vault-settings\nplugin: editor-outliner\nsource: github:archit90/obsidian-editor-outliner\n```\n\n## Editor Defaults (Archit)\n\nThis plugin. Its link and date behaviours are on by default, and it reads this note.\n\n```vault-settings\nplugin: editor-defaults-archit\nsource: github:archit90/obsidian-editor-defaults-archit\n```\n";

// src/setup/setup.ts
var BRAT = "obsidian42-brat";
var ALWAYS_IGNORED = { [BRAT]: ["pluginList", "pluginSubListFrozenVersion", "themesList"] };
var IGNORED_EVERYWHERE = ["previousRelease"];
var OWN_LOCAL = ["setupNote", "setupEnabled"];
var SETTINGS_GRACE_MS = 3e3;
var CHECK_DELAY_MS = 300;
var NOTE_DELAY_MS = 1e3;
var FIRST_RUN_KEY = "editor-defaults-archit:setup-applied";
var VaultSetup = class {
  constructor(host) {
    this.host = host;
    this.status = { note: "missing", errors: [], install: [], uninstall: [], differences: [], lastRun: 0 };
    this.note = null;
    this.snapshots = /* @__PURE__ */ new Map();
    this.states = {};
    this.queue = Promise.resolve();
    this.applying = false;
    this.dirty = /* @__PURE__ */ new Set();
    this.timers = /* @__PURE__ */ new Map();
    this.guard = new DriftGuard();
    this.settingsClosedAt = 0;
    this.userTypesUntil = 0;
    /** What was declined this session ("Not now"): not asked again unless it changes, or by the command. */
    this.declined = null;
    this.warned = /* @__PURE__ */ new Set();
    this.defaultsStore = {};
    this.communityRepos = null;
    this.stopped = false;
    /** The note was just made from the bundled one: the next run asks as on a new device. */
    this.justCreated = false;
    this.isLoaded = (id) => !!this.app.plugins?.plugins?.[id];
  }
  get app() {
    return this.host.app;
  }
  async start() {
    this.defaultsStore = await this.loadDefaultsStore();
    this.watch();
    await this.bootstrap();
    await this.run();
  }
  stop() {
    this.stopped = true;
    for (const t of this.timers.values()) window.clearTimeout(t);
  }
  /** The note's path or the setup's on/off changed: the old note isn't used for any check from now on. */
  forgetNote() {
    this.note = null;
  }
  /** Applies the note now; with `ask`, also asks about installs and removals declined before (and makes a missing note). */
  run(ask = false) {
    const r = this.queue.then(() => this.runNow(ask));
    this.queue = r.catch((e) => console.error("[editor-defaults] vault setup failed", e));
    return r;
  }
  /** The note's hotkeys (for the clash warnings). */
  noteHotkeys() {
    const b = this.here().find((x) => x.kind === "obsidian" && x.target === "hotkeys");
    const out = {};
    if (!b) return out;
    const want = hotkeysTarget(this.app, (id) => this.host.commandName(id)).wanted(b.settings);
    for (const [id, keys] of Object.entries(want))
      if (Array.isArray(keys)) out[id] = keys.filter((k) => typeof k === "string");
    return out;
  }
  // ---------- reading the note ----------
  noteFile() {
    const f = this.app.vault.getAbstractFileByPath(this.host.notePath());
    return f instanceof import_obsidian2.TFile ? f : null;
  }
  async readNote() {
    const f = this.noteFile();
    if (!f) return null;
    return readNote(await this.app.vault.read(f), import_obsidian2.parseYaml);
  }
  here() {
    return (this.note?.blocks ?? []).filter((b) => appliesHere(b, import_obsidian2.Platform.isMobile));
  }
  block(key) {
    return this.here().find((b) => blockKey(b) === key);
  }
  target(key) {
    if (key === "app") return appTarget(this.app);
    if (key === "core-plugins") return corePluginsTarget(this.app, this.isLoaded);
    if (key === "hotkeys") return hotkeysTarget(this.app, (id) => this.host.commandName(id));
    if (key === "property-types") return propertyTypesTarget(this.app);
    if (key.startsWith("config:")) return configFileTarget(this.app, key.slice(7));
    if (key.startsWith("plugin:")) {
      const id = key.slice(7);
      const defaults = id === this.host.manifest.id ? this.host.ownDefaults() : this.defaultsStore[id]?.settings;
      const t = pluginTarget(this.app, id, {
        selfId: this.host.manifest.id,
        ...defaults ? { defaults } : {},
        writeSelf: (all) => this.host.applyOwnSettings(all)
      });
      if (id !== this.host.manifest.id) return t;
      const local = (v) => Object.fromEntries(Object.entries(v).filter(([k]) => !OWN_LOCAL.includes(k)));
      return { ...t, read: async () => local(await t.read()), wanted: (v) => local(t.wanted(v)) };
    }
    return null;
  }
  // ---------- applying ----------
  async runNow(ask) {
    if (this.stopped) return;
    if (!this.host.enabled()) {
      this.note = null;
      this.status = { ...this.status, note: "off", errors: [], install: [], uninstall: [], differences: [] };
      return;
    }
    if (ask) await this.bootstrap();
    this.note = await this.readNote();
    this.guard = new DriftGuard();
    if (!this.note) {
      this.status = { ...this.status, note: "missing", errors: [], install: [], uninstall: [], differences: [] };
      this.warnOnce(
        `missing:${this.host.notePath()}`,
        `Editor Defaults (Archit): there is no settings note at ${this.host.notePath()}; nothing is applied. It's made from the default at the next start (or with the command "Apply the settings note now").`
      );
      return;
    }
    for (const e of this.note.errors)
      this.warnOnce(
        `err:${e.at.line}:${e.message}`,
        `Editor Defaults (Archit): the settings note's block at line ${e.at.line}${e.at.heading ? ` (${e.at.heading})` : ""} isn't used: ${e.message}`
      );
    this.applying = true;
    try {
      const plan = await this.plan();
      const firstRun = this.justCreated || !this.app.loadLocalStorage(FIRST_RUN_KEY);
      const needsAsk = plan.install.length || plan.uninstall.length || firstRun && plan.differences.length;
      let choice = "values";
      const askKey = JSON.stringify([plan.install.map((b) => b.id), plan.uninstall.map((b) => b.id), firstRun]);
      if (needsAsk && (ask || this.declined !== askKey)) {
        while (this.app.setting?.isOpen && !this.stopped) await sleep(500);
        if (this.stopped) return;
        choice = await new SetupModal(this.app, {
          install: plan.install.map((b) => this.pluginLabel(b)),
          uninstall: plan.uninstall.map((b) => this.pluginLabel(b)),
          differences: firstRun ? plan.differences : [],
          notePath: this.host.notePath(),
          canAdopt: firstRun
        }).choose();
        if (choice === "later") this.declined = askKey;
        else {
          this.app.saveLocalStorage(FIRST_RUN_KEY, true);
          this.justCreated = false;
        }
      } else if (needsAsk && firstRun) choice = "later";
      else if (!needsAsk && firstRun) {
        this.app.saveLocalStorage(FIRST_RUN_KEY, true);
        this.justCreated = false;
      }
      if (choice === "adopt") {
        await this.adoptVault();
      } else if (choice !== "later" || !firstRun) {
        if (choice === "apply") {
          for (const b of plan.install)
            await this.install(b).catch((e) => {
              console.error(`[editor-defaults] could not install ${b.id}`, e);
              new import_obsidian2.Notice(`Editor Defaults (Archit) couldn't install ${b.id}: ${String(e)}`, 1e4);
            });
          for (const b of plan.uninstall)
            await this.uninstall(b).catch((e) => console.error(`[editor-defaults] could not remove ${b.id}`, e));
        }
        await this.applyStates();
        await this.applyValues();
        await this.registerWithBrat();
      }
    } finally {
      this.applying = false;
    }
    await this.refreshSnapshots();
    const after = await this.plan();
    this.status = {
      note: "ok",
      errors: this.note.errors,
      install: after.install.map((b) => this.pluginLabel(b)),
      uninstall: after.uninstall.map((b) => this.pluginLabel(b)),
      differences: after.differences,
      lastRun: Date.now()
    };
    this.flushDirty();
  }
  /** A change that came in while applying gets a check of its own. */
  flushDirty() {
    const dirty = [...this.dirty];
    this.dirty.clear();
    for (const k of dirty) this.changed(k);
  }
  pluginLabel(b) {
    const src = b.source.type === "github" ? b.source.repo : "community plugins";
    return `${this.app.plugins?.manifests?.[b.id]?.name ?? b.id} (${src})`;
  }
  /** What applying the note would do: plugins to install or remove, and values the vault holds differently. */
  async plan() {
    const manifests = this.app.plugins?.manifests ?? {};
    const install = [];
    const uninstall = [];
    const diffs = [];
    for (const b of this.here()) {
      if (b.kind === "plugin" && b.id !== this.host.manifest.id) {
        const has = !!manifests[b.id];
        if (b.state === "uninstalled") {
          if (has) uninstall.push(b);
          continue;
        }
        if (!has) {
          install.push(b);
          continue;
        }
        const on = this.app.plugins?.enabledPlugins?.has(b.id) ?? false;
        if (on !== (b.state === "enabled")) diffs.push(`${b.id} ${b.state}`);
      }
      const t = this.target(blockKey(b));
      if (!t) continue;
      const now = await t.read();
      for (const p of differences(t.wanted(b.settings), now)) diffs.push(t.name(p));
    }
    return { install, uninstall, differences: diffs };
  }
  async applyStates() {
    const pm = this.app.plugins;
    if (!pm) return;
    for (const b of this.here()) {
      if (b.kind !== "plugin" || b.id === this.host.manifest.id || !pm.manifests?.[b.id]) continue;
      const on = pm.enabledPlugins?.has(b.id) ?? false;
      if (b.state === "enabled" && !on) await pm.enablePluginAndSave?.(b.id);
      if (b.state === "disabled" && on) await pm.disablePluginAndSave?.(b.id);
    }
  }
  /** Writes every block's values where the vault differs. Returns what was set, as notices name it. */
  async applyValues(only) {
    const done = [];
    for (const b of this.here()) {
      const key = blockKey(b);
      if (only && key !== only) continue;
      if (b.kind === "plugin" && b.id !== this.host.manifest.id && !this.app.plugins?.manifests?.[b.id]) continue;
      const t = this.target(key);
      if (!t) continue;
      const want = t.wanted(b.settings);
      const paths = differences(want, await t.read());
      if (!paths.length) continue;
      try {
        await t.write(want, paths);
        done.push(...paths.map((p) => t.name(p)));
      } catch (e) {
        console.error(`[editor-defaults] could not apply ${key}`, e);
      }
    }
    return done;
  }
  // ---------- installing ----------
  async repoOf(b) {
    if (b.source.type === "github") return b.source.repo;
    if (!this.communityRepos) {
      try {
        const r = await (0, import_obsidian2.requestUrl)(
          "https://raw.githubusercontent.com/obsidianmd/obsidian-releases/HEAD/community-plugins.json"
        );
        const list2 = r.json;
        this.communityRepos = {};
        if (Array.isArray(list2)) {
          for (const e of list2)
            if (isObject(toJson(e))) {
              const o = toJson(e);
              if (isObject(o) && typeof o.id === "string" && typeof o.repo === "string")
                this.communityRepos[o.id] = o.repo;
            }
        }
      } catch (e) {
        console.error("[editor-defaults] could not read Obsidian's community plugin list", e);
        return null;
      }
    }
    return this.communityRepos[b.id] ?? null;
  }
  async install(b) {
    const pm = this.app.plugins;
    const fail = (why) => {
      console.warn(`[editor-defaults] couldn't install ${b.id}: ${why}`);
      new import_obsidian2.Notice(`Editor Defaults (Archit) couldn't install ${b.id}: ${why}`, 1e4);
      return false;
    };
    if (typeof pm?.installPlugin !== "function") return fail("this Obsidian has no plugin installer");
    const repo = await this.repoOf(b);
    if (!repo) return fail("it isn't in Obsidian's community plugin list (or the list couldn't be read)");
    const where = b.version ? `download/${b.version}` : "latest/download";
    const release = `https://github.com/${repo}/releases/${where}/manifest.json`;
    const head = `https://raw.githubusercontent.com/${repo}/HEAD/manifest.json`;
    const urls = b.version ? [release] : b.source.type === "community" ? [head, release] : [release, head];
    let manifest = null;
    for (const url of urls) {
      try {
        const m = (await (0, import_obsidian2.requestUrl)(url)).json;
        if (isPluginManifest(m)) {
          manifest = m;
          break;
        }
      } catch {
      }
    }
    if (!manifest)
      return fail(`no manifest.json in ${repo}'s ${b.version ? `release ${b.version}` : "latest release"}`);
    if (manifest.id !== b.id) return fail(`${repo} is the plugin "${manifest.id}"`);
    if (manifest.minAppVersion && !(0, import_obsidian2.requireApiVersion)(manifest.minAppVersion))
      return fail(`it needs Obsidian ${manifest.minAppVersion}`);
    for (let attempt = 0; attempt < 2 && !pm.manifests?.[b.id]; attempt++) {
      if (attempt) await sleep(2e3);
      await pm.installPlugin(repo, manifest.version, manifest);
      await pm.loadManifests?.();
    }
    const installed = pm.manifests?.[b.id];
    if (!installed) return fail("Obsidian's installer didn't install it");
    const file = `${installed.dir ?? `${this.app.vault.configDir}/plugins/${b.id}`}/data.json`;
    if (!await this.app.vault.adapter.exists(file) && await pm.enablePlugin?.(b.id)) {
      const settings = await this.measureDefaults(b.id, file);
      if (settings) {
        this.defaultsStore[b.id] = { version: manifest.version, settings };
        await this.saveDefaultsStore();
      }
      await pm.disablePlugin?.(b.id);
    }
    if (Object.keys(b.settings).length) {
      const t = this.target(`plugin:${b.id}`);
      if (t) await writeJsonFile(this.app, file, { ...await t.read(), ...structuredClone(b.settings) });
    }
    if (b.state === "enabled") await pm.enablePluginAndSave?.(b.id);
    return true;
  }
  /**
   * A plugin's defaults, just after it loaded without settings: its settings object (some keep it in a settings
   * manager, some fill it a moment after loading), or else the data.json it wrote while loading.
   */
  async measureDefaults(id, file) {
    for (let i = 0; i < 20; i++) {
      const p = asRecord(this.app.plugins?.plugins?.[id]);
      const s = asRecord(p?.settings);
      const m = asRecord(p?.settingsManager);
      for (const c of [p?.settings, s?.settings, s?.data, m?.settings]) {
        const j = toJson(c);
        if (isObject(j) && Object.keys(j).length) return j;
      }
      const written = await readJsonFile(this.app, file);
      if (Object.keys(written).length) return written;
      await sleep(100);
    }
    return null;
  }
  async uninstall(b) {
    await this.app.plugins?.uninstallPlugin?.(b.id);
  }
  /** Adds the note's GitHub plugins to BRAT's list, so BRAT updates them (a pinned version stays pinned). */
  async registerWithBrat() {
    const pm = this.app.plugins;
    const wanted = this.here().filter(
      (b) => b.kind === "plugin" && b.source.type === "github" && b.state !== "uninstalled"
    );
    if (!wanted.length || !pm?.manifests?.[BRAT]) return;
    const brat = asRecord(pm.plugins?.[BRAT]);
    const live = brat && isRecord(brat.settings) ? brat.settings : null;
    const file = `${pm.manifests[BRAT]?.dir ?? `${this.app.vault.configDir}/plugins/${BRAT}`}/data.json`;
    const data = live ?? await readJsonFile(this.app, file);
    const listed = Array.isArray(data.pluginList) ? data.pluginList : data.pluginList = [];
    const frozen = Array.isArray(data.pluginSubListFrozenVersion) ? data.pluginSubListFrozenVersion : data.pluginSubListFrozenVersion = [];
    let changed = false;
    for (const b of wanted) {
      const version = b.version ?? "latest";
      if (!listed.includes(b.source.repo)) {
        listed.push(b.source.repo);
        changed = true;
      }
      const entry = frozen.find((e) => isRecord(e) && e.repo === b.source.repo);
      if (!entry) {
        frozen.push({ repo: b.source.repo, version });
        changed = true;
      } else if (entry.version !== version) {
        entry.version = version;
        changed = true;
      }
    }
    if (!changed) return;
    const save = brat?.saveSettings;
    if (live && typeof save === "function") await Reflect.apply(save, brat, []);
    else {
      const json = toJson(data);
      if (isObject(json)) await writeJsonFile(this.app, file, json);
    }
  }
  // ---------- watching ----------
  settingsWindowRecently() {
    return !!this.app.setting?.isOpen || Date.now() - this.settingsClosedAt < SETTINGS_GRACE_MS;
  }
  watch() {
    const app = this.app;
    const self = this;
    const cfg = app.vault.configDir;
    const reg = (cb) => this.host.register(cb);
    const ev = (ref) => this.host.registerEvent(ref);
    ev(app.vault.on("config-changed", () => this.changed("app")));
    const core = app.internalPlugins;
    if (typeof core?.on === "function") ev(core.on("change", () => this.changed("core-plugins")));
    const hm = app.hotkeyManager;
    if (hm && typeof hm.save === "function")
      reg(
        around(hm, {
          save: (next) => function(...args) {
            const saved = next ? Reflect.apply(next, this, args) : void 0;
            void Promise.resolve(saved).then(
              () => self.changed("hotkeys"),
              () => void 0
            );
            return saved instanceof Promise ? saved : Promise.resolve();
          }
        })
      );
    const setting = app.setting;
    if (setting && typeof setting.onClose === "function")
      reg(
        around(setting, {
          onClose: (next) => function(...args) {
            self.settingsClosedAt = Date.now();
            return next ? Reflect.apply(next, this, args) : void 0;
          }
        })
      );
    const mtm = app.metadataTypeManager;
    const markTypes = () => {
      if (!self.applying) self.userTypesUntil = Date.now() + SETTINGS_GRACE_MS;
    };
    if (mtm && typeof mtm.setType === "function")
      reg(
        around(mtm, {
          setType: (next) => async function(...args) {
            markTypes();
            await (next ? Reflect.apply(next, this, args) : void 0);
            self.changed("property-types");
          },
          unsetType: (next) => async function(...args) {
            markTypes();
            await (next ? Reflect.apply(next, this, args) : void 0);
            self.changed("property-types");
          }
        })
      );
    ev(
      app.vault.on("raw", (path) => {
        if (path === this.host.notePath()) return;
        if (!path.startsWith(`${cfg}/`)) return;
        const rel = path.slice(cfg.length + 1);
        if (rel === "hotkeys.json") return this.changed("hotkeys");
        if (rel === "types.json") return this.changed("property-types");
        if (rel === "community-plugins.json") return this.changed("plugins");
        const pd = /^plugins\/([^/]+)\/(data\.json|manifest\.json)$/.exec(rel);
        if (pd) {
          if (pd[2] === "manifest.json") return this.changed("plugins");
          const id = this.idOfDir(`${cfg}/plugins/${pd[1]}`);
          if (id) this.changed(`plugin:${id}`);
          return;
        }
        if (/^plugins\/[^/]+$/.test(rel)) return this.changed("plugins");
        const cf = /^([a-z0-9][a-z0-9._-]*)\.json$/i.exec(rel);
        if (cf && !isReservedConfig(cf[1])) this.changed(`config:${cf[1]}`);
      })
    );
    const onNote = (f, old) => {
      const p = this.host.notePath();
      if (f.path === p || old === p) this.later("note", NOTE_DELAY_MS, () => void this.run());
    };
    ev(app.vault.on("modify", (f) => onNote(f)));
    ev(app.vault.on("create", (f) => onNote(f)));
    ev(app.vault.on("delete", (f) => onNote(f)));
    ev(app.vault.on("rename", (f, old) => onNote(f, old)));
  }
  idOfDir(dir) {
    for (const [id, m] of Object.entries(this.app.plugins?.manifests ?? {})) if (m?.dir === dir) return id;
    return null;
  }
  later(key, ms, fn) {
    const t = this.timers.get(key);
    if (t !== void 0) window.clearTimeout(t);
    this.timers.set(
      key,
      window.setTimeout(() => {
        this.timers.delete(key);
        if (!this.stopped) fn();
      }, ms)
    );
  }
  /** Something the setup watches changed: check it shortly, as one check per thing. */
  changed(key) {
    if (this.stopped || !this.note || !this.host.enabled()) return;
    if (this.applying) {
      this.dirty.add(key);
      return;
    }
    const user = key === "property-types" ? Date.now() < this.userTypesUntil : this.settingsWindowRecently();
    this.later(`check:${key}`, CHECK_DELAY_MS, () => {
      this.queue = this.queue.then(() => this.check(key, user || this.settingsWindowRecently())).then(() => this.host.checked?.(key)).catch((e) => console.error(`[editor-defaults] could not check ${key}`, e));
    });
  }
  async refreshSnapshots() {
    this.states = this.pluginStates();
    const keys = /* @__PURE__ */ new Set(["app", "core-plugins", "hotkeys", "property-types"]);
    for (const id of Object.keys(this.app.plugins?.manifests ?? {})) keys.add(`plugin:${id}`);
    for (const b of this.note?.blocks ?? []) keys.add(blockKey(b));
    try {
      const listing = await this.app.vault.adapter.list(this.app.vault.configDir);
      for (const f of listing.files) {
        const m = /\/([a-z0-9][a-z0-9._-]*)\.json$/i.exec(f);
        if (m && !isReservedConfig(m[1]) && m[1] !== "types" && m[1] !== "community-plugins")
          keys.add(`config:${m[1]}`);
      }
    } catch {
    }
    for (const k of keys) {
      const t = this.target(k);
      if (t) this.snapshots.set(k, await t.read());
    }
  }
  pluginStates() {
    const out = {};
    const pm = this.app.plugins;
    for (const id of Object.keys(pm?.manifests ?? {})) out[id] = pm?.enabledPlugins?.has(id) ? "enabled" : "disabled";
    return out;
  }
  /**
   * One watched thing changed: a change made in Settings goes into the note; any other is put back from the note,
   * each setting at most 5 times in 10 s (then once that window has passed, by itself) and 10 times in 10 minutes
   * (then not again until the note changes or Obsidian restarts). `retry`: the check at the end of such a window.
   */
  async check(key, user, retry = false) {
    if (this.stopped || !this.note) return;
    if (key === "plugins") return this.checkPlugins(user);
    const t = this.target(key);
    if (!t) return;
    const before = this.snapshots.get(key) ?? {};
    const after = await t.read();
    this.snapshots.set(key, after);
    if (!retry && equal(before, after)) return;
    if (user && !retry) return this.captureChange(key, t, before, after);
    const b = this.block(key);
    if (!b) return;
    const want = t.wanted(b.settings);
    const now = Date.now();
    const paths = differences(want, after).filter((p) => {
      const id = `${key}|${p}`;
      if (this.guard.allow(id, now)) return true;
      const at = this.guard.retryAt(id, now);
      if (at !== null)
        this.later(`retry:${key}`, Math.max(0, at - now) + 50, () => {
          this.queue = this.queue.then(() => this.check(key, false, true)).catch(() => void 0);
        });
      return false;
    });
    const stopped = this.guard.takeStopped();
    if (stopped.length)
      new import_obsidian2.Notice(
        `Editor Defaults (Archit) stopped putting back ${list(stopped.map((id) => t.name(id.split("|")[1])))}: it keeps being changed again (another plugin or device). It's put back again after Obsidian restarts or the settings note changes.`,
        15e3
      );
    if (!paths.length) return;
    for (const p of paths) this.guard.record(`${key}|${p}`, now);
    this.applying = true;
    try {
      await t.write(want, paths);
    } finally {
      this.applying = false;
    }
    this.snapshots.set(key, await t.read());
    this.flushDirty();
    new import_obsidian2.Notice(
      `Editor Defaults (Archit) put back ${list(paths.map((p) => t.name(p)))} from the settings note. To change ${paths.length > 1 ? "these" : "this"}, change it in Settings or in ${this.host.notePath()}.`,
      8e3
    );
  }
  // ---------- taking changes into the note ----------
  /** Writes a change made in Settings into the note: the block's YAML, and a dated line per key. */
  async captureChange(key, t, before, after) {
    const b = this.note?.blocks.find((x) => blockKey(x) === key);
    let result;
    if (key === "core-plugins") result = captureCore(b?.settings ?? {}, before, after, t, this.isLoaded);
    else {
      const id = key.slice(7);
      const ignore = key.startsWith("plugin:") ? [
        ...b?.kind === "plugin" ? b.ignore : [],
        ...ALWAYS_IGNORED[id] ?? [],
        ...IGNORED_EVERYWHERE,
        ...id === this.host.manifest.id ? OWN_LOCAL : []
      ] : [];
      result = capture(b?.settings ?? {}, before, after, { ignore, ...t.defaults ? { defaults: t.defaults } : {} });
    }
    if (!result.added.length && !result.changed.length && !result.removed.length) return;
    const date = (0, import_obsidian2.moment)().format("YYYY-MM-DD");
    const lines = [
      ...result.added.map((p) => `\`${p}\` added from Settings, ${date}.`),
      ...result.changed.map((p) => `\`${p}\` changed in Settings, ${date}.`),
      ...result.removed.map((p) => `\`${p}\` back to its default in Settings, ${date}: taken out.`)
    ];
    if (b) await this.writeBlock(key, blockValue(b, result.values), lines);
    else await this.appendBlock(key, result.values, lines);
    const names = [...result.added, ...result.changed, ...result.removed].map((p) => t.name(p));
    new import_obsidian2.Notice(`Editor Defaults (Archit) saved to the settings note: ${list(names)}.`, 5e3);
  }
  async checkPlugins(user) {
    const before = this.states;
    const after = this.pluginStates();
    this.states = after;
    const ids = /* @__PURE__ */ new Set([...Object.keys(before), ...Object.keys(after)]);
    const changes = [];
    for (const id of ids) {
      const now = after[id] ?? "uninstalled";
      if ((before[id] ?? "uninstalled") !== now) changes.push([id, now]);
    }
    if (!changes.length) return;
    for (const [id] of changes) {
      const t = this.target(`plugin:${id}`);
      if (t && !this.snapshots.has(`plugin:${id}`)) this.snapshots.set(`plugin:${id}`, await t.read());
    }
    if (!user) {
      if (changes.some(([id]) => this.block(`plugin:${id}`))) {
        this.applying = true;
        try {
          await this.applyStates();
        } finally {
          this.applying = false;
        }
        this.states = this.pluginStates();
        this.flushDirty();
      }
      return;
    }
    const date = (0, import_obsidian2.moment)().format("YYYY-MM-DD");
    for (const [id, state] of changes) {
      if (id === this.host.manifest.id) continue;
      const b = this.note?.blocks.find((x) => x.kind === "plugin" && x.id === id);
      const word = state === "uninstalled" ? "uninstalled" : state === "enabled" ? "turned on" : "turned off";
      if (b && b.kind === "plugin") {
        if (b.state === state) continue;
        await this.writeBlock(`plugin:${id}`, blockValue({ ...b, state }, b.settings), [
          `${word} in Settings, ${date}.`
        ]);
      } else if (state !== "uninstalled") {
        const source = await this.sourceOf(id);
        const stub = {
          kind: "plugin",
          id,
          source,
          state,
          ignore: [],
          at: { from: 0, to: 0, end: 0, yaml: "", heading: "", line: 0 },
          settings: {}
        };
        await this.appendBlock(`plugin:${id}`, {}, [`${word} in Settings, ${date}.`], stub);
      }
      new import_obsidian2.Notice(`Editor Defaults (Archit) saved to the settings note: ${id} ${word}.`, 5e3);
    }
  }
  /** Where an installed plugin came from: BRAT's list (GitHub) when a repo there is named after it, else the community. */
  async sourceOf(id) {
    const dir = this.app.plugins?.manifests?.[BRAT]?.dir;
    if (dir) {
      const data = await readJsonFile(this.app, `${dir}/data.json`);
      const repos = Array.isArray(data.pluginList) ? data.pluginList : [];
      for (const repo of repos) {
        if (typeof repo !== "string") continue;
        const name = repo.toLowerCase().split("/")[1] ?? "";
        if (name === id.toLowerCase() || name === `obsidian-${id.toLowerCase()}`) return { type: "github", repo };
      }
    }
    return { type: "community" };
  }
  /** Rewrites one block in the note (found again by its key, as the note may have changed) and adds lines after it. */
  async writeBlock(key, value, lines) {
    const f = this.noteFile();
    if (!f) return;
    await this.app.vault.process(f, (text) => {
      const n = readNote(text, import_obsidian2.parseYaml);
      const b = n.blocks.find((x) => blockKey(x) === key);
      if (!b) return text;
      const updated = replaceBlockYaml(text, b.at, (0, import_obsidian2.stringifyYaml)(value));
      const again = findBlocks(updated).find((x) => x.from === b.at.from);
      return again ? addLinesAfter(updated, again, lines) : updated;
    });
    this.note = await this.readNote();
  }
  async appendBlock(key, settings, lines, stub) {
    const f = this.noteFile();
    if (!f) return;
    const base = stub ?? await this.newBlock(key);
    const heading = base.kind === "plugin" ? this.app.plugins?.manifests?.[base.id]?.name ?? base.id : key.replace(/^config:/, "");
    const yaml = (0, import_obsidian2.stringifyYaml)(blockValue(base, settings));
    await this.app.vault.process(f, (text) => {
      const withSection = appendSection(text, heading, lines.map((l) => `- ${l}`).join("\n"), yaml);
      return withSection;
    });
    this.note = await this.readNote();
  }
  async newBlock(key) {
    const at = { from: 0, to: 0, end: 0, yaml: "", heading: "", line: 0 };
    if (key.startsWith("plugin:")) {
      const id = key.slice(7);
      return { kind: "plugin", id, source: await this.sourceOf(id), state: "enabled", ignore: [], at, settings: {} };
    }
    const target = key === "app" || key === "core-plugins" || key === "hotkeys" || key === "property-types" ? key : key;
    return { kind: "obsidian", target, at, settings: {} };
  }
  // ---------- the note from the vault ----------
  /** The note's blocks get the vault's values for what they manage (first run: "Update the note from this vault"). */
  async adoptVault() {
    for (const b of this.note?.blocks ?? []) {
      const key = blockKey(b);
      const t = this.target(key);
      if (!t) continue;
      const now = await t.read();
      let values = {};
      if (key === "core-plugins") {
        for (const [id, v] of Object.entries(b.settings)) {
          const on = now[id];
          if (typeof on !== "boolean") continue;
          values[id] = isObject(v) ? { ...v, enabled: on } : on;
        }
      } else {
        for (const [k, v] of Object.entries(b.settings)) {
          const have = now[k];
          if (have === void 0) continue;
          values[k] = isObject(v) && isObject(have) ? pick(v, have) : have;
        }
        if (t.defaults) values = withoutDefaults(values, t.defaults);
      }
      let state = b.kind === "plugin" ? b.state : void 0;
      if (b.kind === "plugin" && b.id !== this.host.manifest.id) {
        const m = this.app.plugins?.manifests?.[b.id];
        if (m) state = this.app.plugins?.enabledPlugins?.has(b.id) ? "enabled" : "disabled";
      }
      const next = b.kind === "plugin" && state ? { ...b, state } : b;
      if (equal(values, b.settings) && next === b) continue;
      await this.writeBlock(key, blockValue(next, values), [
        `taken from this vault, ${(0, import_obsidian2.moment)().format("YYYY-MM-DD")}.`
      ]);
    }
  }
  /**
   * The vault has no settings note (at start, or after the setting moved it): it gets the one bundled with the plugin
   * (src/vault-settings.md, the author's setup), dated now. Nothing is applied yet: the run that follows asks, as on a
   * new device (apply it, or take this vault's values into it), and installs ask as always. Returns whether it was made.
   */
  async bootstrap() {
    if (this.stopped || !this.host.enabled() || this.noteFile()) return false;
    const path = this.host.notePath();
    const dir = path.includes("/") ? path.slice(0, path.lastIndexOf("/")) : "";
    try {
      if (dir && !this.app.vault.getAbstractFileByPath(dir)) await this.app.vault.createFolder(dir);
      await this.app.vault.create(path, bundledNote((0, import_obsidian2.moment)().format("YYYY-MM-DDTHH:mm:ss")));
    } catch (e) {
      console.error(`[editor-defaults] could not create the settings note at ${path}`, e);
      return false;
    }
    this.justCreated = true;
    new import_obsidian2.Notice(`Editor Defaults (Archit) created the settings note ${path} from its default.`, 8e3);
    return true;
  }
  /** Every block gets the vault's current values (the command "Update the settings note from this vault"). */
  async updateNoteFromVault() {
    this.note = await this.readNote();
    if (!this.note) return;
    this.applying = true;
    try {
      await this.adoptVault();
    } finally {
      this.applying = false;
    }
    await this.refreshSnapshots();
  }
  // ---------- small things ----------
  warnOnce(key, text) {
    if (this.warned.has(key)) return;
    this.warned.add(key);
    new import_obsidian2.Notice(text, 1e4);
  }
  defaultsFile() {
    return `${this.host.manifest.dir ?? `${this.app.vault.configDir}/plugins/${this.host.manifest.id}`}/plugin-defaults.json`;
  }
  async loadDefaultsStore() {
    const raw = await readJsonFile(this.app, this.defaultsFile());
    const out = {};
    for (const [id, v] of Object.entries(raw))
      if (isObject(v) && typeof v.version === "string" && isObject(v.settings))
        out[id] = { version: v.version, settings: v.settings };
    return out;
  }
  async saveDefaultsStore() {
    const json = toJson(this.defaultsStore);
    if (isObject(json)) await writeJsonFile(this.app, this.defaultsFile(), json);
  }
};
function captureCore(settings, before, after, t, isLoaded) {
  const values = { ...settings };
  const out = { values, added: [], changed: [], removed: [] };
  for (const [id, on] of Object.entries(after)) {
    if (typeof on !== "boolean" || before[id] === on) continue;
    const mine = settings[id];
    if (isObject(mine)) {
      if (typeof mine.onlyWith === "string" && !isLoaded(mine.onlyWith)) continue;
      if (mine.enabled !== on) {
        values[id] = { ...mine, enabled: on };
        out.changed.push(id);
      }
      continue;
    }
    const dflt = typeof t.defaults === "function" ? t.defaults(id) : void 0;
    if (dflt === on) {
      if (mine !== void 0) {
        delete values[id];
        out.removed.push(id);
      }
    } else if (mine === void 0) {
      values[id] = on;
      out.added.push(id);
    } else if (mine !== on) {
      values[id] = on;
      out.changed.push(id);
    }
  }
  return out;
}
function pick(shape, have) {
  const out = {};
  for (const [k, v] of Object.entries(shape)) {
    const h = have[k];
    if (h === void 0) continue;
    out[k] = isObject(v) && isObject(h) ? pick(v, h) : h;
  }
  return out;
}
var sleep = (ms) => new Promise((r) => window.setTimeout(r, ms));
function isRecord(v) {
  return typeof v === "object" && v !== null && !Array.isArray(v);
}
function asRecord(v) {
  return isRecord(v) ? v : null;
}
function isPluginManifest(v) {
  return isRecord(v) && typeof v.id === "string" && typeof v.version === "string" && typeof v.name === "string";
}
function bundledNote(created) {
  return vault_settings_default.replace(/^created: .*$/m, `created: ${created}`);
}

// src/links.ts
var WIKILINK = /\[\[([^[\]|]*)(?:\|([^[\]]*))?\]\]/g;
function isLinkTrigger(textBeforeQuery) {
  return textBeforeQuery.endsWith("[[");
}
function linkAt(line, ch) {
  for (const m of line.matchAll(WIKILINK)) {
    const from = m.index;
    const to = from + m[0].length;
    if (ch <= from || ch > to) continue;
    const target = m[1] ?? "";
    const hash = target.indexOf("#");
    return {
      from,
      to,
      path: hash < 0 ? target : target.slice(0, hash),
      subpath: hash < 0 ? "" : target.slice(hash),
      alias: m[2]
    };
  }
  return null;
}
function fixPickedLink(line, ch, fix) {
  const l = linkAt(line, ch);
  if (!l) return null;
  const alias = fix.dropAlias !== void 0 && l.alias === fix.dropAlias ? void 0 : l.alias;
  const path = fix.path ?? l.path;
  if (alias === l.alias && path === l.path) return null;
  const text = `[[${path}${l.subpath}${alias !== void 0 ? `|${alias}` : ""}]]`;
  const oldPathEnd = 2 + l.path.length;
  const oldTargetEnd = oldPathEnd + l.subpath.length;
  const oldAliasEnd = oldTargetEnd + (l.alias !== void 0 ? 1 + l.alias.length : 0);
  const newPathEnd = 2 + path.length;
  const newTargetEnd = newPathEnd + l.subpath.length;
  const newAliasEnd = newTargetEnd + (alias !== void 0 ? 1 + alias.length : 0);
  const off = ch - l.from;
  let at;
  if (off <= oldPathEnd) at = off === oldPathEnd ? newPathEnd : Math.min(off, newPathEnd);
  else if (off <= oldTargetEnd) at = off - oldPathEnd + newPathEnd;
  else if (off <= oldAliasEnd) at = alias !== void 0 ? off - oldTargetEnd + newTargetEnd : newTargetEnd;
  else at = off - oldAliasEnd + newAliasEnd;
  return { from: l.from, to: l.to, text, ch: l.from + at };
}

// src/properties.ts
var import_obsidian3 = require("obsidian");
var ISO_FIELDS = {
  date: { placeholder: "YYYY-MM-DD", picker: "date" },
  datetime: { placeholder: "YYYY-MM-DD HH:mm:ss", picker: "datetime-local" }
};
function pickedText(type, picked) {
  if (type === "date") return picked.slice(0, 10);
  const t = picked.slice(0, 19);
  return shownDateTime(t.length === 16 ? `${t}:00` : t);
}
function shownDateTime(value) {
  return value.replace(/^(\d{4}-\d{2}-\d{2})T/, "$1 ");
}
function isoDateTime(text) {
  return text.trim().replace(/^(\d{4}-\d{2}-\d{2})\s+(?=\d)/, "$1T");
}
function pickerValue(type, text) {
  const t = text.trim();
  if (type === "date") return /^\d{4}-\d{2}-\d{2}/.test(t) ? t.slice(0, 10) : "";
  const m = /^(\d{4}-\d{2}-\d{2})(?:[T ](\d{2}:\d{2}(?::\d{2})?))?/.exec(t);
  if (!m) return "";
  const time = m[2] ?? "00:00:00";
  return `${m[1]}T${time.length === 5 ? `${time}:00` : time}`;
}
function isIsoText(type, text) {
  const t = text.trim();
  if (t === "") return true;
  if (type === "date") return (0, import_obsidian3.moment)(t, "YYYY-MM-DD", true).isValid();
  return (0, import_obsidian3.moment)(isoDateTime(t), ["YYYY-MM-DD[T]HH:mm:ss", "YYYY-MM-DD[T]HH:mm", "YYYY-MM-DD"], true).isValid();
}
function canonicalText(type, text) {
  const t = text.trim();
  if (t === "" || !isIsoText(type, t)) return text;
  if (type === "date") return t;
  const m = (0, import_obsidian3.moment)(isoDateTime(t), ["YYYY-MM-DD[T]HH:mm:ss", "YYYY-MM-DD[T]HH:mm", "YYYY-MM-DD"], true);
  return m.format("YYYY-MM-DD HH:mm:ss");
}
function invalidDateNotice(type, typed, stored) {
  const back = stored.trim() === "" ? "empty" : `"${type === "datetime" ? canonicalText(type, shownDateTime(stored)) : stored}"`;
  return `"${typed.trim()}" isn't a valid ${type === "datetime" ? "date & time" : "date"} (use ${ISO_FIELDS[type].placeholder}), so it wasn't saved. The field is back to ${back}.`;
}
function isInput(x) {
  return typeof x === "object" && x !== null && "tagName" in x && x.tagName === "INPUT";
}
function isDateWidget(w) {
  return typeof w === "object" && w !== null && "inputEl" in w && isInput(w.inputEl);
}
function isoifyWidget(type, rendered, el) {
  if (!isDateWidget(rendered)) return;
  const widget = rendered;
  const input = widget.inputEl;
  if (input.dataset.isoDate) return;
  input.dataset.isoDate = "1";
  const shown = (v) => type === "datetime" ? canonicalText(type, shownDateTime(v)) : v;
  const value = input.value;
  input.type = "text";
  input.value = shown(value);
  const parse = widget.parse?.bind(widget);
  if (parse)
    widget.parse = (text) => {
      const ok = isIsoText(type, text);
      input.toggleClass("is-invalid", !ok);
      input.setAttr("aria-invalid", ok ? "false" : "true");
      input.style.outline = ok ? "" : "1px solid var(--text-error)";
      input.title = ok ? "" : `Use ${ISO_FIELDS[type].placeholder}`;
      parse(ok ? type === "datetime" ? isoDateTime(text) : text : "not a date");
    };
  if (type === "datetime") {
    const setValue = widget.setValue?.bind(widget);
    if (setValue)
      widget.setValue = (value2) => {
        setValue(value2);
        input.value = shown(input.value);
      };
  }
  input.addEventListener("blur", () => {
    if (input.getAttr("aria-invalid") === "true") {
      const typed = input.value;
      const stored = widget.value ?? "";
      if (widget.setValue) widget.setValue(stored);
      else {
        input.value = shown(stored);
        widget.parse?.(input.value);
      }
      new import_obsidian3.Notice(invalidDateNotice(type, typed, stored));
      return;
    }
    const text = canonicalText(type, input.value);
    if (text !== input.value) input.value = text;
  });
  input.placeholder = ISO_FIELDS[type].placeholder;
  input.spellcheck = false;
  const button = el.createDiv({
    cls: "clickable-icon iso-date-picker",
    attr: { "aria-label": "Pick a date", role: "button", tabindex: "0" }
  });
  (0, import_obsidian3.setIcon)(button, "calendar");
  const picker = el.createEl("input", {
    cls: "iso-date-hidden-picker",
    // step 1: the date & time picker offers seconds too
    attr: { type: ISO_FIELDS[type].picker, step: "1", tabindex: "-1", "aria-hidden": "true" }
  });
  el.addClass("iso-date-host");
  button.addEventListener("keydown", (e) => {
    if (e.key === "Enter" || e.key === " ") {
      e.preventDefault();
      button.click();
    }
  });
  button.addEventListener("click", (e) => {
    e.preventDefault();
    e.stopPropagation();
    picker.value = pickerValue(type, input.value);
    try {
      picker.showPicker();
    } catch {
      picker.focus();
      picker.click();
    }
  });
  picker.addEventListener("change", () => {
    if (!picker.value) return;
    input.value = pickedText(type, picker.value);
    input.dispatchEvent(new Event("input"));
    input.dispatchEvent(new Event("blur"));
  });
}

// src/settings.ts
var import_obsidian4 = require("obsidian");
var DEFAULT_NOTE = "Vault settings.md";
var OLD_DEFAULT_NOTE = "_s/Vault settings.md";
var DEFAULTS = {
  forceRootPaths: true,
  stripAlias: true,
  isoDates: true,
  setupEnabled: true,
  setupNote: DEFAULT_NOTE
};
var SETTING_NAMES = {
  forceRootPaths: "Heading and block links use the path from the vault root",
  stripAlias: "Insert [[path]] without alias",
  isoDates: "Dates in properties as YYYY-MM-DD (date & time with seconds)",
  setupEnabled: "Set up the vault from the settings note",
  setupNote: "Settings note"
};
var BOOL_KEYS = ["forceRootPaths", "stripAlias", "isoDates", "setupEnabled"];
function parseSettings(raw) {
  const out = { ...DEFAULTS };
  if (typeof raw !== "object" || raw === null) return out;
  const get = (key) => Object.hasOwn(raw, key) ? Reflect.get(raw, key) : void 0;
  for (const key of BOOL_KEYS) {
    const v = get(key);
    if (typeof v === "boolean") out[key] = v;
  }
  const note = get("setupNote");
  if (typeof note === "string" && note.trim().endsWith(".md") && note.trim() !== OLD_DEFAULT_NOTE)
    out.setupNote = note.trim();
  return out;
}
var logError = (e) => console.error("[editor-defaults] could not save the settings", e);
var EditorDefaultsTab = class extends import_obsidian4.PluginSettingTab {
  constructor(app, plugin) {
    super(app, plugin);
    this.plugin = plugin;
    /** The note path as typed: applied when the field loses focus or the tab closes, never half-typed. */
    this.noteDraft = null;
  }
  toggle(desc, key) {
    new import_obsidian4.Setting(this.containerEl).setName(SETTING_NAMES[key]).setDesc(desc).addToggle(
      (t) => t.setValue(this.plugin.settings[key]).onChange((v) => {
        this.plugin.settings[key] = v;
        const saved = key === "isoDates" ? this.plugin.isoDatesChanged() : this.plugin.saveSettings();
        saved.catch(logError);
      })
    );
  }
  commitNote() {
    const draft = this.noteDraft?.trim();
    this.noteDraft = null;
    if (!draft || draft === this.plugin.settings.setupNote || !draft.endsWith(".md")) return;
    this.plugin.settings.setupNote = draft;
    this.plugin.saveSettings().catch(logError);
  }
  hide() {
    this.commitNote();
    super.hide();
  }
  display() {
    const { containerEl } = this;
    containerEl.empty();
    this.toggle(
      "Picking a note from the [[ dropdown inserts only the link target, not [[path|name]]. Works with absolute and relative link formats, in notes and in properties.",
      "stripAlias"
    );
    this.toggle(
      'While "New link format" is "Absolute path in vault", heading and block links picked from the [[ dropdown get the full path too.',
      "forceRootPaths"
    );
    this.toggle(
      "Date and Date & time properties show and take YYYY-MM-DD (date & time: YYYY-MM-DD HH:mm:ss) instead of your system's date format; the calendar button still opens a date picker.",
      "isoDates"
    );
    new import_obsidian4.Setting(containerEl).setName("Vault setup").setHeading();
    containerEl.createEl("p", {
      cls: "setting-item-description",
      text: "The settings note lists this vault's plugins (where they come from, whether they're on) and the settings that differ from the defaults: Obsidian's, the core plugins', the hotkeys, the property types and each plugin's. Editor Defaults (Archit) applies it at start and whenever it changes. A change you make in Settings is written into the note; a change made any other way (a synced file, another plugin) is put back. Installing or removing a plugin always asks first."
    });
    this.toggle("Apply the settings note and keep it up to date.", "setupEnabled");
    new import_obsidian4.Setting(containerEl).setName(SETTING_NAMES.setupNote).setDesc("Path from the vault root. Applied when you leave the field.").addText((t) => {
      t.setValue(this.noteDraft ?? this.plugin.settings.setupNote).onChange((v) => {
        this.noteDraft = v;
      });
      t.inputEl.addEventListener("blur", () => this.commitNote());
    });
    const st = this.plugin.setup.status;
    const status = new import_obsidian4.Setting(containerEl).setName("Status");
    const lines = [];
    if (st.note === "off") lines.push("Off.");
    else if (st.note === "missing") lines.push(`There is no note at ${this.plugin.settings.setupNote}.`);
    else {
      const d = st.differences;
      lines.push(
        d.length ? `The vault differs from the note in ${d.length}: ${d.slice(0, 5).join("; ")}${d.length > 5 ? "\u2026" : ""}` : "The vault matches the note."
      );
      if (st.install.length) lines.push(`To install: ${st.install.join(", ")}.`);
      if (st.uninstall.length) lines.push(`To remove: ${st.uninstall.join(", ")}.`);
      for (const e of st.errors) lines.push(`Block at line ${e.at.line} isn't used: ${e.message}`);
    }
    status.setDesc(lines.join("\n"));
    status.descEl.addClass("editor-defaults-status");
    if (st.note === "missing")
      status.addButton(
        (b) => b.setButtonText("Create from the default").setCta().onClick(() => void this.plugin.setup.run(true).then(() => this.display()))
      );
    else if (st.note === "ok") {
      status.addButton(
        (b) => b.setButtonText("Apply now").onClick(() => void this.plugin.setup.run(true).then(() => this.display()))
      );
      status.addButton((b) => b.setButtonText("Open the note").onClick(() => void this.plugin.openSetupNote()));
    }
  }
};

// src/main.ts
var logError2 = (what) => (e) => console.error(`[editor-defaults] ${what}`, e);
function linkSuggestion(item) {
  if (typeof item !== "object" || item === null) return {};
  return {
    file: "file" in item && item.file instanceof import_obsidian5.TFile ? item.file : void 0,
    type: "type" in item && typeof item.type === "string" ? item.type : void 0
  };
}
function isCoreLinkSuggest(s) {
  if (typeof s !== "object" || s === null || !("suggestManager" in s)) return false;
  const m = s.suggestManager;
  return typeof m === "object" && m !== null && "getFileSuggestions" in m && typeof m.getFileSuggestions === "function";
}
function isPropertyLinkSuggestProto(proto) {
  return typeof proto === "object" && proto !== null && Object.hasOwn(proto, "selectSuggestion") && Object.hasOwn(proto, "getLinktextQuery") && "selectSuggestion" in proto && typeof proto.selectSuggestion === "function";
}
var EditorDefaultsPlugin = class extends import_obsidian5.Plugin {
  constructor() {
    super(...arguments);
    this.settings = { ...DEFAULTS };
    /** Set on unload: whatever is still running (the layout-ready callback) stops there. */
    this.unloaded = false;
    /** Hotkey clashes already warned about this session ("other command|hotkey"). */
    this.warnedClashes = /* @__PURE__ */ new Set();
    /** The settings note and on/off the setup last ran with: a change of either runs it again. */
    this.setupKey = "";
  }
  async onload() {
    const midSession = this.app.workspace.layoutReady;
    this.settings = parseSettings(await this.loadData());
    this.patchDateWidgets();
    this.addSettingTab(new EditorDefaultsTab(this.app, this));
    this.setup = new VaultSetup({
      app: this.app,
      manifest: this.manifest,
      notePath: () => this.settings.setupNote,
      enabled: () => this.settings.setupEnabled,
      ownDefaults: () => ({ ...DEFAULTS }),
      applyOwnSettings: (all) => this.applyOwnSettings(all),
      commandName: (id) => this.commandName(id),
      register: (cb) => this.register(cb),
      registerEvent: (ref) => this.registerEvent(ref),
      checked: (key) => {
        if (key === "hotkeys") this.warnHotkeyClashes();
      }
    });
    this.setupKey = this.currentSetupKey();
    this.addCommands();
    this.app.workspace.onLayoutReady(() => {
      if (this.unloaded) return;
      this.setup.start().then(() => this.warnHotkeyClashes()).catch(logError2("could not set up the vault"));
      this.patchLinkSuggest();
      this.patchPropertyLinkSuggest();
      if (midSession && this.settings.isoDates) this.rerenderDateFields();
    });
  }
  onunload() {
    this.unloaded = true;
    this.setup?.stop();
    if (this.settings.isoDates) this.rerenderDateFields();
  }
  /** data.json changed on disk (this plugin's settings from another device, through sync): use them at once. */
  async onExternalSettingsChange() {
    if (this.unloaded) return;
    const before = this.settings;
    this.settings = parseSettings(await this.loadData());
    if (before.isoDates !== this.settings.isoDates) this.rerenderDateFields();
    await this.runSetupIfMoved();
  }
  async saveSettings() {
    await this.saveData(this.settings);
    await this.runSetupIfMoved();
  }
  currentSetupKey() {
    return `${this.settings.setupEnabled}|${this.settings.setupNote}`;
  }
  /** The settings note's path or the setup's on/off changed since it last ran: run it with them. */
  async runSetupIfMoved() {
    const key = this.currentSetupKey();
    if (key === this.setupKey) return;
    this.setupKey = key;
    this.setup.forgetNote();
    await this.setup.bootstrap();
    await this.setup.run();
  }
  /** The "Dates in properties" setting changed: redraw the date fields of open notes and Bases. */
  async isoDatesChanged() {
    await this.saveSettings();
    this.rerenderDateFields();
  }
  /** The settings note's block for this plugin: its settings, as data.json holds them. */
  async applyOwnSettings(all) {
    const next = {
      ...parseSettings(all),
      setupNote: this.settings.setupNote,
      setupEnabled: this.settings.setupEnabled
    };
    const before = this.settings;
    this.settings = next;
    await this.saveData(next);
    if (before.isoDates !== next.isoDates) this.rerenderDateFields();
  }
  async openSetupNote() {
    const f = this.app.vault.getAbstractFileByPath(this.settings.setupNote);
    if (f instanceof import_obsidian5.TFile) await this.app.workspace.getLeaf(true).openFile(f);
    else new import_obsidian5.Notice(`Editor Defaults (Archit): there is no note at ${this.settings.setupNote}.`);
  }
  addCommands() {
    this.addCommand({
      id: "apply-settings-note",
      name: "Apply the settings note now",
      callback: () => void this.setup.run(true).then(() => this.warnHotkeyClashes())
    });
    this.addCommand({
      id: "show-differences",
      name: "Show what differs from the settings note",
      callback: () => void this.setup.plan().then((p) => {
        const lines = [
          ...p.install.map((b) => `install ${b.id}`),
          ...p.uninstall.map((b) => `remove ${b.id}`),
          ...p.differences
        ];
        new import_obsidian5.Notice(
          lines.length ? `Editor Defaults (Archit): the vault differs from the settings note in:
${lines.join("\n")}` : "Editor Defaults (Archit): the vault matches the settings note.",
          lines.length ? 15e3 : 4e3
        );
      })
    });
    this.addCommand({
      id: "update-settings-note",
      name: "Update the settings note from this vault",
      callback: () => void this.setup.updateNoteFromVault().then(() => new import_obsidian5.Notice("Editor Defaults (Archit) updated the settings note."))
    });
    this.addCommand({
      id: "open-settings-note",
      name: "Open the settings note",
      callback: () => void this.openSetupNote()
    });
  }
  /** A command's name, or its id while its plugin isn't loaded. */
  commandName(id) {
    return this.app.commands?.findCommand?.(id)?.name ?? id;
  }
  /**
   * Warns (once per clash per session) when another command has one of the hotkeys the settings note sets: Obsidian
   * runs only one of them. The other command's hotkey is left alone. A hotkey whose command doesn't exist (its
   * plugin isn't installed) clashes with nothing.
   */
  warnHotkeyClashes() {
    const hm = this.app.hotkeyManager;
    if (this.unloaded || !hm) return;
    const wanted = {};
    for (const [id, keys] of Object.entries(this.setup.noteHotkeys()))
      wanted[id] = keys.flatMap((k) => {
        const h = parseHotkey(k);
        return h ? [h] : [];
      });
    const commands = { ...this.app.commands?.editorCommands, ...this.app.commands?.commands };
    const effective = {};
    for (const id of Object.keys(commands)) effective[id] = hm.getHotkeys?.(id) ?? hm.getDefaultHotkeys?.(id) ?? [];
    for (const c of hotkeyClashes(wanted, effective, import_obsidian5.Platform.isMacOS || import_obsidian5.Platform.isIosApp)) {
      const key = `${c.other}|${c.label}`;
      if (this.warnedClashes.has(key)) continue;
      this.warnedClashes.add(key);
      const name = (id) => this.app.commands?.findCommand?.(id)?.name ?? commands[id]?.name ?? id;
      new import_obsidian5.Notice(
        `Editor Defaults (Archit): ${c.label} (${name(c.command)}) is also the hotkey of "${name(c.other)}", so it may run that instead. Change or remove one of them in Settings \u2192 Hotkeys.`,
        1e4
      );
    }
  }
  /**
   * Redraws every Date / Date & time property field (notes in tabs, cards and canvases, the File properties view,
   * Bases tabs), so turning "Dates in properties" on or off, or the plugin, shows at once. Obsidian redraws a
   * property everywhere when its type changes ("changed" on the metadata type manager); nothing is saved.
   */
  rerenderDateFields() {
    const mtm = this.app.metadataTypeManager;
    if (!mtm || typeof mtm.trigger !== "function") return;
    const props = mtm.getAllProperties?.() ?? {};
    for (const [key, info] of Object.entries(props))
      if (info?.widget === "date" || info?.widget === "datetime") mtm.trigger("changed", key);
    for (const leaf of this.app.workspace.getLeavesOfType("bases"))
      leaf.rebuildView?.()?.catch(logError2("could not redraw a Bases tab"));
  }
  /** Date / Date & time property widgets: ISO text fields (see properties.ts). Undone on unload. */
  patchDateWidgets() {
    const widgets = this.app.metadataTypeManager?.registeredTypeWidgets;
    if (!widgets) return;
    const plugin = this;
    const types = ["date", "datetime"];
    for (const type of types) {
      const w = widgets[type];
      if (typeof w?.render !== "function") continue;
      this.register(
        around(w, {
          render: (next) => function(el, ...rest) {
            const widget = next ? Reflect.apply(next, this, [el, ...rest]) : void 0;
            if (plugin.settings.isoDates) {
              try {
                isoifyWidget(type, widget, el);
              } catch (e) {
                console.error("[editor-defaults] could not change the date field", e);
              }
            }
            return widget;
          }
        })
      );
    }
  }
  /**
   * What to change in a link just picked from a [[ dropdown: the note name Obsidian adds as an alias to a note
   * pick, and, for a heading or block pick (where Obsidian keeps the note name as typed), the path from the
   * vault root when new links use it.
   */
  pickFix(raw, sourcePath) {
    const fix = {};
    const item = linkSuggestion(raw);
    const file = item.file;
    if (!file) return fix;
    if (item.type === "file" && this.settings.stripAlias) fix.dropAlias = file.basename;
    if ((item.type === "heading" || item.type === "block") && this.settings.forceRootPaths && this.app.vault.getConfig?.("newLinkFormat") === "absolute")
      fix.path = this.app.metadataCache.fileToLinktext(file, sourcePath, true);
    return fix;
  }
  /** Wraps selectSuggestion on Obsidian's own [[ link suggester in the editor (undone on unload). */
  patchLinkSuggest() {
    const suggest = (this.app.workspace.editorSuggest?.suggests ?? []).find(isCoreLinkSuggest);
    if (!suggest) {
      console.warn("[editor-defaults] Obsidian's [[ link suggester wasn't found: picked links keep their alias");
      return;
    }
    const plugin = this;
    this.register(
      around(suggest, {
        selectSuggestion: (next) => function(item, ...rest) {
          const ctx = this.context;
          const editor = ctx?.editor;
          const before = ctx && editor ? editor.getRange({ line: ctx.start.line, ch: Math.max(0, ctx.start.ch - 2) }, ctx.start) : "";
          const fix = isLinkTrigger(before) ? plugin.pickFix(item, ctx?.file?.path ?? "") : {};
          const result = Reflect.apply(next, this, [item, ...rest]);
          if (editor && (fix.dropAlias !== void 0 || fix.path !== void 0)) fixLinkAtCursor(editor, fix);
          return result;
        }
      })
    );
  }
  /**
   * The [[ suggester in property values is created per field, from a class Obsidian doesn't export. It is an
   * AbstractInputSuggest that shows its suggestions through the base class, so its prototype is patched the
   * first time one shows (undone on unload).
   */
  patchPropertyLinkSuggest() {
    const plugin = this;
    const patched = /* @__PURE__ */ new Set();
    const patchProto = (proto) => {
      patched.add(proto);
      this.register(
        around(proto, {
          selectSuggestion: (next) => function(item, ...rest) {
            const fix = plugin.pickFix(item, this.sourcePath ?? "");
            if (fix.dropAlias === void 0 && fix.path === void 0) {
              Reflect.apply(next, this, [item, ...rest]);
              return;
            }
            const apply = (text, ch) => {
              const r = fixPickedLink(text, ch, fix);
              return r ? { text: text.slice(0, r.from) + r.text + text.slice(r.to), ch: r.ch } : null;
            };
            const onSelect = this.onSelectLink;
            let committed = false;
            if (typeof onSelect === "function")
              this.onSelectLink = (text, e) => {
                committed = true;
                onSelect.call(this, apply(text, text.length)?.text ?? text, e);
              };
            try {
              Reflect.apply(next, this, [item, ...rest]);
            } finally {
              this.onSelectLink = onSelect;
            }
            if (!committed) fixFieldLink(this.inputEl, apply);
          }
        })
      );
    };
    const base = import_obsidian5.AbstractInputSuggest.prototype;
    this.register(
      around(base, {
        showSuggestions: (next) => function(...args) {
          try {
            const proto = Object.getPrototypeOf(this);
            if (isPropertyLinkSuggestProto(proto) && !patched.has(proto) && "onSelectLink" in this && typeof this.onSelectLink === "function")
              patchProto(proto);
          } catch (e) {
            console.error("[editor-defaults] could not patch the property link suggester", e);
          }
          Reflect.apply(next, this, args);
        }
      })
    );
  }
};
function fixLinkAtCursor(editor, fix) {
  const cursor = editor.getCursor();
  const r = fixPickedLink(editor.getLine(cursor.line), cursor.ch, fix);
  if (!r) return;
  editor.replaceRange(r.text, { line: cursor.line, ch: r.from }, { line: cursor.line, ch: r.to });
  editor.setCursor({ line: cursor.line, ch: r.ch });
}
function fixFieldLink(el, apply) {
  const text = el.textContent ?? "";
  const sel = el.win.getSelection();
  let ch = text.length;
  if (sel && sel.focusNode && el.contains(sel.focusNode)) {
    const range = el.doc.createRange();
    range.setStart(el, 0);
    range.setEnd(sel.focusNode, sel.focusOffset);
    ch = range.toString().length;
  }
  const r = apply(text, ch);
  if (!r) return;
  el.textContent = r.text;
  if (sel && el.firstChild) sel.collapse(el.firstChild, r.ch);
  el.dispatchEvent(new Event("input"));
}
