---
type: system
created: 2026-11-04T18:52:00
---

# Note System

Two axes: **time** (logs) × **topic** (zettels, entities). Projects and areas carry action. MOCs and dashboards are entry points. **Links are the backbone**: always link down to topics, and let backlinks build history.

## Folders

| Folder | Types | Mutable? |
|---|---|---|
| `0/` | `log` | Prose frozen (see below) |
| `z/` | `zettel` | Yes |
| `n/` | `entity` | Yes |
| `p/` | `project`, `area` | Yes |
| `x/` | `moc`, `dashboard` | Yes |
| `_s/` | `system` | Yes |
| `_t/` | Templates (no schema) | — |
| `u/` | Uploads (all attachments, flat) | Never moved |
| `c/` | Canvases (`.canvas`; core Canvas creates new ones here) | Yes |
| `d/` | Excalidraw drawings (`.excalidraw.md`, no schema), also those created from a note; Excalidraw's templates, scripts and libraries in `d/` subfolders | Yes |

Links use absolute paths, for example `[[z/Memory]]` or `[[n/Memory]]`. Typing `[[z/` filters autocomplete by folder.

## Properties

Every note has `type` and `created`. Beyond that, a note carries only the properties meaningful for its type. Links in properties are quoted, as in `parents: ["[[z/X]]"]` or `parent: "[[x/X]]"`.

| Property | Format | Used on | Values |
|---|---|---|---|
| `type` | text | all | `log` `zettel` `entity` `project` `area` `moc` `dashboard` `system` |
| `created` | datetime | all | `YYYY-MM-DDTHH:mm:ss`, set by the template |
| `aliases` | list | zettel, entity, project, area, moc | alternate names |
| `status` | text | log | `inbox` `linked` `distilled` |
| | | project | `active` `paused` `done` |
| `distill` | checkbox | log | whether the log holds an idea worth keeping |
| `topics` | list of links | log | what the log is about |
| `parents` | list of links | zettel | broader zettels or MOCs |
| `parent` | link | moc | the one broader MOC |
| `sources` | list of links | zettel | entities the idea came from |
| `kind` | text | entity | `book` `person` `org` `tool` `series` |
| `author` | list of links | entity (book) | people in `n/` |
| `year` | number | entity (book) | year of publication |
| `url` | text | entity (book, org, tool) | |
| `org` | list of links | entity (person) | orgs in `n/` |
| `cadence` | text | entity (series) | `daily` `weekly` `monthly` … |
| `area` | list of links | project | areas the project belongs to |
| `due` | date | project | optional deadline |
| `private` | checkbox | any (optional) | exclude the note from exports |
| `canvas-full-backlinks-enabled` | checkbox | any (optional) | `true` shows the note's Backlinks Full View panes on its canvas cards when they're not being edited too (off by default; while editing they always show). Set by the pane's "Enable in canvas" button |
| `backlinks` | list of objects | any (optional) | the note's own Backlinks Full View panes: `title`, `filter`, `sort`, `query`. The built-in All backlinks pane is never stored here. Templates pre-fill it; leave it out of `types.json` |
| `backlinks-open` | list of paths | any (optional) | written by Backlinks Full View: the note's expanded cards, all panes, most recent first (at most the plugin setting, default 50). Never write it by hand; leave it out of `types.json` |

## Note types

### Log (`0/`) · `type: log`
- Records what happened, was read, or was thought. A quick capture is just a short log.
- Filename: `YYYY-MM-DD-HHmmss` plus an optional ` title`, flat in `0/`.
- **Prose is frozen.** These changes are allowed:
  - task-line metadata (checkbox, dates)
  - moving a task out, leaving `→ [[p/X]]` in its place
  - adding a title to the filename
  - fixing typos
  - redacting sensitive data
- A reading session is a log linked to the book. A meeting is a log linked to its series.

### Zettel (`z/`) · `type: zettel`
- One idea per note. It grows over time.
- Title the note as the idea itself. Add a qualifier only on collision, as in `Memory (computing)`.
- `parents` may be empty at creation. More than 3 parents means the note should be split, or replaced with an MOC.
- No todos. Its **Children** pane lists the zettels that name it as a parent.

### Entity (`n/`) · `type: entity`
- **Rule:** an entity is a proper-named thing that exists outside your head. Anything conceptual goes in `z/`.
- There is one template per `kind`. Each has panes for its linked logs and the zettels that cite it.

### Project (`p/`) · `type: project`
- Multi-step work with an end. Body: **Goal · Current state · Next actions**.
- Archive it by setting `status: done`.

### Area (`p/`) · `type: area`
- A responsibility with no end, such as health, finances or a habit. Body: **Standard · Current state · Recurring**.
- Recurring todos live **only** in areas. Its **Projects** pane lists its projects.

### MOC (`x/`) · `type: moc`
- A hand-curated hub across zettels, used only where the parent hierarchy isn't enough.
- At most one `parent`, another MOC. Its **Sub-MOCs** pane lists its sub-MOCs.

### Dashboard (`x/`) · `type: dashboard`
- A query-driven view (todos, reviews, checks).

### System (`_s/`) · `type: system`
- Notes about the vault itself.

## Plugins

- **All of them, and their settings,** are listed in `Vault settings.md` at the vault root, with the reasons. Editor Defaults (Archit) keeps the vault in line with it: it installs a listed plugin after one click, applies the settings, writes a change you make in Settings back into the note (dated), and puts back a change made any other way.
- **Community:** Templater, Dataview, Tasks, Advanced Tables, Calendar, Style Settings, Advanced Canvas, Enhanced Canvas, PDF++, Omnisearch, Excalidraw, BRAT (keeps the custom plugins updated).
- **Core:** Bases on. Templates, Unique note creator and Backlinks off (Templater replaces Templates, Backlinks Full View replaces Backlinks; each is kept off only while its replacement is enabled).
- **Custom:** the built plugins ship inside the vault in `.obsidian/plugins/<id>/`, installed from their GitHub releases and kept updated by BRAT (on Obsidian's start, or its command "Check for updates to all beta plugins and UPDATE"). Each has its own repository (`archit90/obsidian-backlinks-full-view`, `obsidian-editor-defaults-archit`, `obsidian-editor-multiple-lanes`, `obsidian-editor-outliner`). Each works without the others; together, Backlinks Full View panes also show under lane cards.
  - **Backlinks Full View** (`backlinks-full-view`): panes below each note that show its backlinks, or a Dataview query's results, as collapsible full-note cards.
    - **All backlinks:** every note gets this pane, always first and collapsed when the note opens. Its search, filter and sort are never saved (they don't touch the note); its expanded cards are remembered like every pane's (below). Its cards are built on first expand.
    - **The note's own panes:** one per entry in its `backlinks` property, titled.
    - Cards start collapsed and render on first expand. Expanded cards are saved in the note's `backlinks-open` property, one list for all its panes (a remembered note opens expanded in every pane that shows it): the 50 most recent by default (setting "Remembered expanded cards"; 0 saves none). A note leaves the list once no pane shows it (deleted, renamed, no longer linking or matching).
    - Templates pre-fill the panes (Logs, Ideas, Children, Projects…), so notes carry no in-note query blocks.
    - **Embedded notes** (setting "Show embedded notes as cards", on by default): `![[note]]` shows the note as a collapsible card like those in the panes, collapsed at first, with its properties when expanded. An embed in a list item or a sentence stays on that line as a compact card. Every card, in the panes and in embeds, is titled with the note's full path (setting "Full path in note cards", on by default; off: the name and a faint folder label). `![[note#heading]]` and `![[note#^block]]` stay Obsidian's embeds.
    - **Canvas** (setting "Show backlinks panes on canvas cards", on by default): a note's card on a canvas always shows its panes while you edit it. When it's not being edited, they show only once the note opts in with "Enable in canvas" (next to "+ Add backlinks pane"), which sets `canvas-full-backlinks-enabled: true`; "Disable in canvas" removes it.
    - Expanded cards show the note's properties above its text. Links in cards follow Obsidian's conventions: click, Ctrl/Cmd-click or middle-click for a new tab, and hover with Ctrl/Cmd for a preview.
    - **Search** matches paths, tags and properties, plus note text when *Full text* is ticked. Words next to each other must all match, and `OR`, `NOT` (or `-word`), `"quoted phrases"` and parentheses work, e.g. `(billing AND v2) OR acme`. Operators must be in capitals.
  - **Editor Defaults (Archit)** (`editor-defaults-archit`): sets the vault up from `Vault settings.md` (above), and inserts `[[path]]` links without the `|alias` Obsidian adds, in notes and in properties. Date properties show and take `YYYY-MM-DD`, Date & time properties `YYYY-MM-DD HH:mm:ss`, whatever the system's locale (a calendar button still opens a picker). Text that isn't a date goes back to the saved value, with a notice, when you leave the field.
  - **Editor Multiple Lanes** (`editor-multiple-lanes`): notes open in lanes, side-by-side columns of editable notes inside a tab, instead of one tab each.
    - Each lanes tab ("Editor lane <name>") is laid out from a definition such as `50, 50` or `40, 30x2, 30`: the default in its settings, or the tab's own from **Lane layout…**. Only lane sizes change by hand (drag the dividers).
    - A link followed in a lane opens in the next lane; notes from the explorer, search or quick switcher go to the lane used last; Ctrl/Cmd-click opens a new lanes tab.
    - Each note is a collapsible card with its folder and an editable name (renames the file), a Reading / editing button, a pin, and a close button. Drag cards between lanes; drop files or links onto a lane to open them there.
    - On phones a tab shows one lane at a time; swipe between lanes.
  - **Editor Outliner** (`editor-outliner`): outliner editing for headings and nested lists, in tabs, lanes, Canvas cards, popout windows and page previews. On mobile the toolbar's indent / outdent buttons move an item or heading with its children.
    - **Tab / Shift+Tab** demote or promote a heading with its whole section, or indent / outdent a list item with its children. A list item never leaves its list.
    - **Ctrl+↑/↓** (**Cmd+↑/↓** on Mac) move the selected items or sections, else the heading section, list item or paragraph at the cursor, with its children; **Alt+↑** / **Alt+↓** grow the selection up / down (word, line, then whole blocks: the siblings that way, at the edge the parent, then its siblings… up to the note's top level) and **Alt+Shift+↑** / **Alt+Shift+↓** take that edge back.
    - Headings with 7 or more `#` count as deeper levels. Vertical guides show each heading's section; in Live Preview a faint **H1**…**H6** label after each heading shows its level; a drag handle left of each heading, item or block moves it.
    - **Outline mode** (always on, no switch): inside a list, Enter, Shift+Enter, Backspace, Delete and paste work as in Logseq: Enter splits an item, Backspace at an item's start merges it into the item above, pasted Markdown becomes items; Enter on the last empty item leaves the list. A list item can hold several paragraphs and code blocks (Dataview queries too).
    - When **Alt+↑** / **Alt+↓** reach a whole item or section, ←/→ fold or go to the parent / child, Backspace deletes them, and copying gives clean Markdown.

## Templates (`_t/`)

Templater is the only template engine. Templates never prompt. Each one sets `type` and `created`, then moves the note to its folder.

| Template | Creates | Folder template for |
|---|---|---|
| `log` | log, named `YYYY-MM-DD-HHmmss` | `0` |
| `zettel` | zettel | `z` |
| `entity` | entity, `kind` empty | `n` |
| `entity-book`, `entity-person`, `entity-org`, `entity-tool`, `entity-series` | entity with `kind` set | — |
| `project` | project | `p` |
| `area` | area | — |
| `moc` | MOC | `x` |
| `dashboard` | dashboard | — |
| `system` | system note | `_s` |

Every note except a log is named `YYYYMMDDHHmmss`, which never collides, and you rename it yourself. Logs can gain a title later.

## Queries

**Dataview is the default** for the weekly review, dashboards and every check. Note-level lists (Logs, Children, Ideas, Projects…) are Backlinks Full View panes, some of which run a Dataview query.

**Bases** are used only where they clearly beat Dataview:
- `x/daily review.base`: a table of `status: inbox` logs where you edit `status`, `distill` and `topics` in place.
- `x/unreferenced uploads.base`: files in `u/` with no backlinks. Bases see attachments natively, so no dataviewjs is needed. Canvas references may be missed, so check before deleting.

**Tasks** handles todos (`x/todos`).

## Todos
- Todos live only in **logs** (captured), **projects** (planned) and **areas** (recurring).
- Tasks uses its **Dataview format**, never emoji: `- [ ] Book flights [due:: 2026-11-12]`, `[repeat:: every week]`, `[completion:: 2026-11-05]`, `[scheduled:: …]`, `[start:: …]`, `[priority:: high]`.
- One dashboard (`x/todos`) collects every open todo.

## Reviews

**Daily (5–10 min): triage**
- For each `status: inbox` log:
  - link it to topics, entities and projects
  - date its todos, or move them to a project
  - add a title if it's worth finding again
  - set `distill: true` only if it holds an idea worth keeping
- Set `status: linked`.
- A `linked` log with `distill: false` is **done**.

**Weekly (long): distill and maintain**
- Turn `distill: true` logs into new or updated zettels, then set `status: distilled`.
- Update each active project's current state and next actions. Pause or close stale projects. Check areas.
- Run the checks in `x/weekly review`:
  - orphan zettels and empty parents
  - zettels with more than 3 parents, and parent cycles
  - schema errors (a `type` not allowed in its folder, a bad `status`, a missing `created`)
  - unrenamed notes (a bare timestamp name outside `0/`)
  - basenames that appear in more than one folder
  - unlinked mentions
- Delete unreferenced uploads (see `x/unreferenced uploads.base`). They go to the Obsidian trash, so check before you empty it.

A `distill: true` log older than 14 days means the weekly review is slipping.

## Rules of thumb
- Folders are for tidiness. Filters use properties.
- A file in `u/` never moves. Name uploads `YYYY-MM-DD-HHmmss name.ext`.
- Every new note links to at least one topic, entity, project or area at creation, or by the next daily review.
- If unsure where something goes, write a log and decide during review.
- Never create names that differ only by case.
- **Secrets never enter the vault.** Passwords and IDs go in a password manager.
- **Backup:** keep a git or off-sync backup in addition to sync and File recovery.
- Required settings on **every device** (mobile included):
  - Enforced by Editor Defaults (Archit):
    - New link format: *absolute path in vault*
    - Attachments: folder `u`
    - Deleted files: *Obsidian trash*
    - Core Bases: enabled. Core Templates, Unique note creator and Backlinks: disabled
    - Hotkeys: Navigate back = Ctrl/Cmd+Alt+← and Ctrl/Cmd+[; Navigate forward = Ctrl/Cmd+Alt+→ and Ctrl/Cmd+]; Templater "Create new note from template" = Alt+N; Templater "Open insert template modal" = none. If another command has one of these hotkeys, Editor Defaults (Archit) warns once (it doesn't change your hotkey); change one of them in Settings → Hotkeys.
    - Date and Date & time properties shown as `YYYY-MM-DD` / `YYYY-MM-DD HH:mm:ss`
  - Set by hand:
    - Templater template folder: `_t`, and trigger on new file creation: on
    - Folder templates as in the Templates table
    - A Templater hotkey for `_t/log`
    - Canvas: default location for new canvases = folder `c`
    - Excalidraw: drawing folder `d`, "Use Excalidraw folder when embedding a drawing" on (so drawings made from a note go to `d/` too, not `u/`)
