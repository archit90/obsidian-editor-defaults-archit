---
type: project
created: 2026-11-05T08:40:00
aliases: []
status: active
area: ["[[p/Languages]]"]
due: 2027-03-31
backlinks:
  - title: Logs
    filter: '{"type":"group","mode":"and","children":[{"type":"rule","prop":"file.folder","op":"is","value":"0"}]}'
    sort: '[{"prop":"file.name","dir":"desc"}]'
---

## Goal
Pass an A1 Spanish exam.

## Current state
Working through the first course unit.

## Next actions
- [ ] Book the exam date
