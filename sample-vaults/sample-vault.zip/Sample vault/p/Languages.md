---
type: area
created: 2026-11-05T08:30:00
aliases: []
backlinks:
  - title: Projects
    sort: '[{"prop":"note.status","dir":"asc"},{"prop":"note.due","dir":"asc"}]'
    query: 'LIST FROM "p" WHERE type = "project" AND contains(area, this.file.link)'
  - title: Logs
    filter: '{"type":"group","mode":"and","children":[{"type":"rule","prop":"file.folder","op":"is","value":"0"}]}'
    sort: '[{"prop":"file.name","dir":"desc"}]'
---

## Standard
Practise Spanish a little most days.

## Current state
Studying for A1.

## Recurring
- [ ] Spanish review session [repeat:: every week] [due:: 2026-11-08]
