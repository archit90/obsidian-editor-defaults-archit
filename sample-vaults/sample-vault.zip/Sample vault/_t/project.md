---
type: project
created: <% tp.date.now("YYYY-MM-DDTHH:mm:ss") %>
aliases: []
status: active
area: []
due:
backlinks:
  - title: Logs
    filter: '{"type":"group","mode":"and","children":[{"type":"rule","prop":"file.folder","op":"is","value":"0"}]}'
    sort: '[{"prop":"file.name","dir":"desc"}]'
---

## Goal
<% tp.file.cursor() %>

## Current state

## Next actions
- [ ] 
<%* await tp.file.move("p/" + tp.date.now("YYYYMMDDHHmmss")) -%>
