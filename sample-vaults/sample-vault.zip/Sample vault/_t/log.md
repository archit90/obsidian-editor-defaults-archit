---
type: log
created: <% tp.date.now("YYYY-MM-DDTHH:mm:ss") %>
status: inbox
distill: false
topics: []
---

<% tp.file.cursor() %>
<%* await tp.file.move("0/" + tp.date.now("YYYY-MM-DD-HHmmss")) -%>
