---
type: area
created: <% tp.date.now("YYYY-MM-DDTHH:mm:ss") %>
aliases: []
backlinks:
  - title: Projects
    sort: '[{"prop":"note.status","dir":"asc"},{"prop":"note.due","dir":"asc"}]'
    query: 'LIST FROM "p" WHERE type = "project" AND contains(area, this.file.link)'
  - title: Logs
    filter: '{"type":"group","mode":"and","children":[{"type":"rule","prop":"file.folder","op":"is","value":"0"}]}'
    sort: '[{"prop":"file.name","dir":"desc"}]'
---

## Standard
<% tp.file.cursor() %>

## Current state

## Recurring
- [ ] 
<%* await tp.file.move("p/" + tp.date.now("YYYYMMDDHHmmss")) -%>
