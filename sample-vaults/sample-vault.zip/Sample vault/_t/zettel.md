---
type: zettel
created: <% tp.date.now("YYYY-MM-DDTHH:mm:ss") %>
aliases: []
parents: []
sources: []
backlinks:
  - title: Children
    query: 'LIST FROM "z" WHERE contains(parents, this.file.link)'
---

<% tp.file.cursor() %>
<%* await tp.file.move("z/" + tp.date.now("YYYYMMDDHHmmss")) -%>
