---
type: dashboard
created: <% tp.date.now("YYYY-MM-DDTHH:mm:ss") %>
---

<% tp.file.cursor() %>
<%* await tp.file.move("x/" + tp.date.now("YYYYMMDDHHmmss")) -%>
