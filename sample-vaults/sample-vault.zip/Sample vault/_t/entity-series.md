---
type: entity
created: <% tp.date.now("YYYY-MM-DDTHH:mm:ss") %>
aliases: []
kind: series
cadence:
backlinks:
  - title: Occurrences
    filter: '{"type":"group","mode":"and","children":[{"type":"rule","prop":"file.folder","op":"is","value":"0"}]}'
    sort: '[{"prop":"file.name","dir":"desc"}]'
  - title: Open todos
    sort: '[{"prop":"file.name","dir":"desc"}]'
    query: 'TASK FROM [[]] AND "0" WHERE !completed'
---

<% tp.file.cursor() %>
<%* await tp.file.move("n/" + tp.date.now("YYYYMMDDHHmmss")) -%>
