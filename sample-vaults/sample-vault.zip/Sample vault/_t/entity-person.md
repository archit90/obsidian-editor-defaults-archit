---
type: entity
created: <% tp.date.now("YYYY-MM-DDTHH:mm:ss") %>
aliases: []
kind: person
org: []
backlinks:
  - title: Logs
    filter: '{"type":"group","mode":"and","children":[{"type":"rule","prop":"file.folder","op":"is","value":"0"}]}'
    sort: '[{"prop":"file.name","dir":"desc"}]'
  - title: Authored
    sort: '[{"prop":"note.year","dir":"desc"}]'
    query: 'LIST FROM "n" WHERE contains(author, this.file.link)'
  - title: Ideas
    query: 'LIST FROM "z" WHERE contains(sources, this.file.link)'
---

<% tp.file.cursor() %>
<%* await tp.file.move("n/" + tp.date.now("YYYYMMDDHHmmss")) -%>
