---
type: moc
created: <% tp.date.now("YYYY-MM-DDTHH:mm:ss") %>
aliases: []
parent:
backlinks:
  - title: Sub-MOCs
    query: 'LIST FROM "x" WHERE type = "moc" AND parent = this.file.link'
---

<% tp.file.cursor() %>
<%* await tp.file.move("x/" + tp.date.now("YYYYMMDDHHmmss")) -%>
