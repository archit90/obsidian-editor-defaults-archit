---
type: system
created: <% tp.date.now("YYYY-MM-DDTHH:mm:ss") %>
---

<% tp.file.cursor() %>
<%* await tp.file.move("_s/" + tp.date.now("YYYYMMDDHHmmss")) -%>
