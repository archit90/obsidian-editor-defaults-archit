---
type: entity
created: <% tp.date.now("YYYY-MM-DDTHH:mm:ss") %>
aliases: []
kind: book
author: []
year:
url:
backlinks:
  - title: Reading logs
    filter: '{"type":"group","mode":"and","children":[{"type":"rule","prop":"file.folder","op":"is","value":"0"}]}'
    sort: '[{"prop":"file.name","dir":"desc"}]'
  - title: Ideas
    query: 'LIST FROM "z" WHERE contains(sources, this.file.link)'
---

<% tp.file.cursor() %>
<%* await tp.file.move("n/" + tp.date.now("YYYYMMDDHHmmss")) -%>
