---
type: zettel
created: 2026-11-05T09:30:00
aliases: []
parents: ["[[x/Learning]]"]
sources: ["[[n/Make It Stick]]"]
backlinks:
  - title: Children
    query: 'LIST FROM "z" WHERE contains(parents, this.file.link)'
---

Pulling an idea out of memory strengthens it far more than reading it again. The effort is the point: easy review feels fluent and teaches little.
