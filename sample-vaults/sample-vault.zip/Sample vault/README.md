# Vault

A self-contained Obsidian vault. Copy this folder anywhere and open it as a vault: the folders, templates, dashboards, settings and plugins all travel with it.

- **How it works:** read `_s/system.md`. The templates themselves are in `_t/`.
- **Plugins and settings:** `Vault settings.md` lists them, with the reasons. On first open, Obsidian asks whether to trust the vault's plugins: trust them. Editor Defaults (Archit) then offers to install the others (Templater, Dataview, Tasks, Advanced Tables, Calendar, Style Settings, Advanced Canvas, Enhanced Canvas, PDF++, Omnisearch, Excalidraw, BRAT, Backlinks Full View, Editor Multiple Lanes, Editor Outliner) and applies their settings. A setting you change in Settings is written back into the note.
- **Templater hotkey:** `_t/log.md` is registered as a Templater command. Bind a key to it in Settings → Hotkeys ("Templater: Insert _t/log.md").
- **Backup:** run `git init` in your copy and commit regularly, as `_s/system.md` recommends.
