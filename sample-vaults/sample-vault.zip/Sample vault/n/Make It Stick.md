---
type: entity
created: 2026-11-05T08:55:00
aliases: []
kind: book
author: []
year: 2014
url:
backlinks:
  - title: Reading logs
    filter: '{"type":"group","mode":"and","children":[{"type":"rule","prop":"file.folder","op":"is","value":"0"}]}'
    sort: '[{"prop":"file.name","dir":"desc"}]'
  - title: Ideas
    query: 'LIST FROM "z" WHERE contains(sources, this.file.link)'
---

Brown, Roediger and McDaniel on the science of successful learning.
