---
type: dashboard
created: 2026-11-05T00:00:00
---

Every open todo in logs and projects. Recurring todos live in areas.

## Overdue
```tasks
not done
path regex matches /^(0|p)\//
is not recurring
due before today
sort by due
group by filename
```

## Open
```tasks
not done
path regex matches /^(0|p)\//
is not recurring
(no due date) OR (due after yesterday)
sort by due
group by filename
```

## Recurring
```tasks
not done
is recurring
sort by due
group by filename
```
