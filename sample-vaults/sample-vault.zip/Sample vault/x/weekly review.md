---
type: dashboard
created: 2026-11-05T00:00:00
---

Checks for the weekly review. See `_s/system.md`.

## Distill backlog
Logs marked `distill: true` that are not distilled yet, oldest first.
```dataview
TABLE created, choice(date(today) - created > dur(14 days), "⚠️ older than 14 days", "") AS "flag"
FROM "0"
WHERE type = "log" AND distill = true AND status = "linked"
SORT created ASC
```

## Active projects
Least recently edited first.
```dataview
TABLE due, file.mtime AS "edited"
FROM "p"
WHERE type = "project" AND status = "active"
SORT file.mtime ASC
```

## Areas
```dataview
TABLE file.mtime AS "edited"
FROM "p"
WHERE type = "area"
SORT file.mtime ASC
```

## Zettels with empty parents
```dataview
LIST
FROM "z"
WHERE type = "zettel" AND length(default(parents, list())) = 0
SORT file.name
```

## Orphan zettels
No links in or out.
```dataview
LIST
FROM "z"
WHERE type = "zettel" AND length(file.inlinks) = 0 AND length(file.outlinks) = 0
SORT file.name
```

## Zettels with more than 3 parents
Split the note, or replace the parents with an MOC.
```dataview
TABLE length(parents) AS "parents"
FROM "z"
WHERE type = "zettel" AND length(default(parents, list())) > 3
SORT file.name
```

## Parent cycles
Follows `parents` on zettels and `parent` on MOCs.
```dataviewjs
const toArr = (v) => v == null ? [] : Array.isArray(v) ? v : typeof v.array === "function" ? v.array() : [v];
const edges = new Map();
for (const p of dv.pages('"z" or "x"')) {
  const raw = p.type === "zettel" ? p.parents : p.type === "moc" ? p.parent : null;
  edges.set(p.file.path, toArr(raw)
    .filter((l) => l && l.path)
    .map((l) => app.metadataCache.getFirstLinkpathDest(l.path, p.file.path)?.path ?? l.path));
}
const state = new Map(); // 1 = on the DFS stack, 2 = done
const stack = [];
const cycles = new Map();
const visit = (n) => {
  state.set(n, 1);
  stack.push(n);
  for (const m of edges.get(n) ?? []) {
    if (state.get(m) === 1) {
      const cyc = stack.slice(stack.indexOf(m));
      const key = [...cyc].sort().join("|");
      if (!cycles.has(key)) cycles.set(key, cyc);
    } else if (!state.has(m) && edges.has(m)) visit(m);
  }
  stack.pop();
  state.set(n, 2);
};
for (const n of edges.keys()) if (!state.has(n)) visit(n);
if (!cycles.size) dv.paragraph("No parent cycles.");
else dv.list([...cycles.values()].map((c) => [...c, c[0]].map((p) => dv.fileLink(p)).join(" → ")));
```

## Schema errors
A `type` not allowed in its folder, a `status` not allowed for its type, or a missing `created`.
```dataviewjs
const allowed = { "0": ["log"], z: ["zettel"], n: ["entity"], p: ["project", "area"], x: ["moc", "dashboard"], _s: ["system"] };
const statuses = { log: ["inbox", "linked", "distilled"], project: ["active", "paused", "done"] };
const rows = [];
for (const p of dv.pages()) {
  const folder = p.file.path.split("/")[0];
  if (!Object.prototype.hasOwnProperty.call(allowed, folder)) continue;
  const problems = [];
  if (!allowed[folder].includes(p.type)) problems.push(`type "${p.type ?? ""}" not allowed in ${folder}/`);
  if (p.status != null) {
    const ok = statuses[p.type];
    if (!ok || !ok.includes(p.status)) problems.push(`status "${p.status}" not allowed for ${p.type ?? "untyped"}`);
  }
  if (p.created == null) problems.push("missing created");
  if (problems.length) rows.push([p.file.link, problems.join("; ")]);
}
if (rows.length) dv.table(["Note", "Problem"], rows);
else dv.paragraph("No schema errors.");
```

## Unrenamed notes
A bare timestamp name outside `0/`.
```dataview
LIST
WHERE !startswith(file.path, "0/") AND regexmatch("^[0-9]{14}$", file.name)
SORT file.path
```

## Duplicate basenames
Names used more than once, ignoring case. Templates in `_t/` are not notes, so they are skipped.
```dataviewjs
const byName = new Map();
for (const p of dv.pages('-"_t"')) {
  const k = p.file.name.toLowerCase();
  if (!byName.has(k)) byName.set(k, []);
  byName.get(k).push(p.file.link);
}
const rows = [...byName.values()].filter((links) => links.length > 1).map((links) => [links[0].path.split("/").pop().replace(/\.md$/, ""), links]);
if (rows.length) dv.table(["Name", "Notes"], rows);
else dv.paragraph("No duplicate basenames.");
```
