---
type: moc
created: 2026-11-05T09:20:00
aliases: []
parent:
backlinks:
  - title: Sub-MOCs
    query: 'LIST FROM "x" WHERE type = "moc" AND parent = this.file.link'
---

How learning and memory work.

- [[z/Retrieval beats rereading]]
